
#ifndef __TEST__H__
#define __TEST__H__

#include <stdbool.h>

// ~~~ declaraciones de test ~~~
extern void rotar_asm (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);

extern void rotar_128 (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);

extern void rotar_256 (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);

extern void rotar_512 (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);

extern void rotar_1024 (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);

extern void rotar_2048 (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);

#endif   /* !__TEST__H__ */
