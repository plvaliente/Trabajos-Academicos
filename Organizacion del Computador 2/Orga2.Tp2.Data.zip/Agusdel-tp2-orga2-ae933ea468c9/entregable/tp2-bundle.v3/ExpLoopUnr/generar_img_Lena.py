#!/usr/bin/env python
#
# SCRIPT PARA GENERAR IMAGENES DESDE 16X16 A 2048X2048 DE LENA
#
#
#from libtest import *
import subprocess
import sys


IMAGENES=["lena.bmp"]
DATADIR = "./data"
sizes=['128x128', '256x256', '512x512', '1024x1024', '2048x2048']


for filename in IMAGENES:
	for size in sizes:
		name = filename.split('.')
		file_in  = DATADIR + "/" + filename
		file_out = DATADIR + "/" + "source" + "." + size + "." + name[1]
		resize = "convert -resize " + size + "! " + file_in + " " + file_out
		subprocess.call(resize, shell=True)
		file_out = DATADIR + "/" + "dest" + "." + size + "." + name[1]
		resize = "convert -resize " + size + "! " + file_in + " " + file_out
		subprocess.call(resize, shell=True)

