
#include "../tp2.h"

void smalltiles_c (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size) {
	
	unsigned char (*src_matrix)[src_row_size] = (unsigned char (*)[src_row_size]) src;
	unsigned char (*dst_matrix)[dst_row_size] = (unsigned char (*)[dst_row_size]) dst;
	


	for (int f = 0; f < filas / 2; f++) {
		for (int c = 0; c < cols / 2; c++) {

			//pixel fuente
            bgra_t *p_s = (bgra_t*) &src_matrix[2*f][c * 8];
            //4 pixeles destino de las 4 miniimagenes
            bgra_t *p_d1 = (bgra_t*) &dst_matrix[f][c * 4];
            bgra_t *p_d2 = (bgra_t*) &dst_matrix[f][(c+cols / 2) * 4];
            bgra_t *p_d3 = (bgra_t*) &dst_matrix[f + filas / 2][c * 4];
            bgra_t *p_d4 = (bgra_t*) &dst_matrix[f + filas / 2][(c+cols / 2) * 4];

            //primer imagen

			p_d1->b = p_s->b;
			p_d1->g = p_s->g;
			p_d1->r = p_s->r;
			p_d1->a = p_s->a;

            //segunda imagen

			p_d2->b = p_s->b;
			p_d2->g = p_s->g;
			p_d2->r = p_s->r;
			p_d2->a = p_s->a;

            //tercera imagen

			p_d3->b = p_s->b;
			p_d3->g = p_s->g;
			p_d3->r = p_s->r;
			p_d3->a = p_s->a;

            //cuarta imagen

			p_d4->b = p_s->b;
			p_d4->g = p_s->g;
			p_d4->r = p_s->r;
			p_d4->a = p_s->a;									

		}
	}
	
}