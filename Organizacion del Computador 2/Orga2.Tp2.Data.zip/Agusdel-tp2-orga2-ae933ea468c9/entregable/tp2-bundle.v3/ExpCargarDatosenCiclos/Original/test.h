
#ifndef __TEST__H__
#define __TEST__H__

#include <stdbool.h>

// ~~~ declaraciones de test ~~~
extern void colorizar_asm    (unsigned char *src, unsigned char *dst, int cols, int filas,
                      int src_row_size, int dst_row_size, float alpha);

extern void colorizar_asmConMemo    (unsigned char *src, unsigned char *dst, int cols, int filas,
                      int src_row_size, int dst_row_size, float alpha);

extern void colorizar_asmConOperaciones(unsigned char *src, unsigned char *dst, int cols, int filas,
                      int src_row_size, int dst_row_size, float alpha);

#endif   /* !__TEST__H__ */
