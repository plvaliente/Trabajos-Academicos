
#ifndef __TEST__H__
#define __TEST__H__

#include <stdbool.h>

// ~~~ declaraciones de test ~~~
extern void pixelar_asm (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);

extern void pixelar_risc (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);

#endif   /* !__TEST__H__ */
