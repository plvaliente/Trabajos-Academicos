#!/bin/bash

make clean

./generar_img_Lena.py 

make 

lscpu > lscpu.data
cat /proc/cpuinfo > cpuinfo.data

./testSvsR

echo
echo "GUARDO EN data.tar.gz:"
echo
tar -cvzf data.tar.gz *.data
echo
echo "EJECUTO CLEAN"
echo
make clean