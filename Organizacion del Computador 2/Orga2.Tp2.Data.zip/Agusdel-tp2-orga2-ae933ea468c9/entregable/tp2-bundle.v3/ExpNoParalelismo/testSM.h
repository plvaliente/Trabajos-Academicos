
#ifndef __TEST__H__
#define __TEST__H__

#include <stdbool.h>

// ~~~ declaraciones de test ~~~
extern void smalltiles_asm (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);
extern void smalltilesNotParalel_asm (unsigned char *src, unsigned char *dst, int cols, int filas, int src_row_size, int dst_row_size);


#endif   /* !__TEST__H__ */
