
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "testSM.h"
#include "libbmp.h"

//void smalltiles_asm (unsigned char *src, unsigned char *dst, 
//int cols, int filas, int src_row_size, int dst_row_size);

// CARGA UNA IMAGEN Y LE APLICA SMALLTILES
// ESTA MA COPADO PARA TESTEAR DESDE ACA


int comp (const void * elem1, const void * elem2) 
{
    long int f = *((long int*)elem1);
    long int s = *((long int*)elem2);
    if (f > s) return  1;
    if (f < s) return -1;
    return 0;
}


void smalltiles(short func, unsigned char *src, unsigned char *dst, int cols, int filas, int src_row, int dst_row){

	switch (func){
		case 0:
			smalltiles_asm(src, dst, cols, filas, src_row, dst_row);
			break;
		case 1:
			smalltilesNotParalel_asm(src, dst, cols, filas, src_row, dst_row);
			break;
	}

}

int main(int argc, char **argv) { // ARGUMENTOS: INT cantIteraciones (por imagen)

	if( argc > 2 ) {
		printf("Too many arguments supplied.\n");
	}
	else if (argc < 2 ){
		printf("One argument expected.\n");
	}
	else{

		int cantIteraciones = atoi(argv[1]);

		/**Archivos**/
		char* nMed = "smalltiles.data";
		FILE *medF = fopen( nMed, "w" );
		/**INICIALIZO ARREGLO**/
		long int *array = calloc(cantIteraciones, sizeof *array);
		if (array == NULL){
    		printf ("Array allocation failed \n");
		}
		for (short func = 0; func < 2; func++){

			switch (func){
				case 0:
					fprintf (medF, "Smalltiles paralelizada:\n\n");
					printf ("Smalltiles paralelizada:\n");
					break;
				case 1:
					fprintf (medF, "\nSmalltiles no paralelizada:\n\n");
					printf ("Smalltiles no paralelizada:\n");
					break;
			}

			fprintf (medF, "minimo,mediana,promedio90,promedio,maximo,imagen. CANT ITERACIONES: %d \n", cantIteraciones);

			/**LEO IMG**/
			for (double i = 5.0; i < 14.0; i++){

				char imageName [50];
				char destName [50];
				snprintf ( imageName, 50, "./data/lena.%dx%d.bmp", (int)pow(2,i), (int)pow(2,i) );
				snprintf ( destName, 50, "./data/dest.%dx%d.bmp", (int)pow(2,i), (int)pow(2,i) );

				BMP* in = bmp_read(imageName);
				BMP* dest = bmp_read(destName);

				printf ("\n%s \n",imageName);

				if (bmp_compression(in) == BI_RGB && bmp_compression(dest) == BI_RGB) {
					if (bmp_bit_count(in) == 24) {
			    		bmp_convert_24_to_32_bpp(in);
					}		
					if (bmp_bit_count(dest) == 24) {
			    		bmp_convert_24_to_32_bpp(dest);
					}
					uint8_t* src = bmp_data(in);
					uint8_t* dst = bmp_data(dest);
					int cols = (int)pow(2,i);
					int filas = (int)pow(2,i);
					int src_row = (int)pow(2,i)*4;
					int dst_row = (int)pow(2,i)*4;
					/**TIEMPO INIT**/

					long int sum = 0;
					long int sum90 = 0;

					for (int iter = 0; iter < cantIteraciones; iter++){

						clock_t tic = clock();
						/**FUN**/
						smalltiles(func, src, dst, cols, filas, src_row, dst_row);
						/**FUN**/
						tic = clock() - tic;
				 	 	/** TIEMPO FIN**/
			 	 		array[iter] = tic;
			 	 		//printf("%ld  ", tic);
			 	 		sum += tic;
					}
					/**GUARDO IMG**/
					bmp_save(destName, dest);
					/**LIBERO MEM**/
					bmp_delete(in);
					bmp_delete(dest);
				 	/**ORDENO ARRAY Y TOMO MEDIANA**/
					qsort(array, cantIteraciones, sizeof(array[0]), comp);
			    	long int mediana = array[cantIteraciones/2-1];
			    	long int promedio = sum/cantIteraciones;
			    	for (int j = 0; j < cantIteraciones*0.9; j++){sum90 += array[j];}
			    	long int promedio90 = sum90/(cantIteraciones*(0.9));
					fprintf (medF, "%ld,%ld,%ld,%ld,%ld,lena.%dx%d.bmp\n", array[0], mediana, promedio90, promedio, array[cantIteraciones-1], (int)pow(2,i), (int)pow(2,i));
				}
			}
		}
		/**LIBERO MEM**/
		free(array);
		fclose (medF);		
	}
	return 0;
}
