#!/usr/bin/env python
#
# SCRIPT PARA GENERAR IMAGENES DESDE 32X32 A 8192x8192 DE LENA
#
#
#from libtest import *
import subprocess
import sys


IMAGENES=["lena.bmp","dest.bmp"]
DATADIR = "./data"
sizes=['32x32', '64x64', '128x128', '256x256', '512x512', '1024x1024', '2048x2048', '4096x4096', '8192x8192']


for filename in IMAGENES:
	for size in sizes:
		name = filename.split('.')
		file_in  = DATADIR + "/" + filename
		file_out = DATADIR + "/" + name[0] + "." + size + "." + name[1]
		resize = "convert -resize " + size + "! " + file_in + " " + file_out
		subprocess.call(resize, shell=True)
