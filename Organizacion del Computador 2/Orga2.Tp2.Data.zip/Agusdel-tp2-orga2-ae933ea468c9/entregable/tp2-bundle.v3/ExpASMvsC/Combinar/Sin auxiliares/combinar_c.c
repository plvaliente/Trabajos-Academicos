
#include "./test.h"

void combinar_c (
	unsigned char *src, 
	unsigned char *dst, 
	int cols, 
	int filas, 
	int src_row_size,
	int dst_row_size,
	float alpha
) {
	unsigned char (*src_matrix)[src_row_size] = (unsigned char (*)[src_row_size]) src;
	unsigned char (*dst_matrix)[dst_row_size] = (unsigned char (*)[dst_row_size]) dst;

	for (int f = 0; f < filas; f++) {
		for (int c = 0; c < cols; c++) {
			bgra_t *p_d = (bgra_t*) &dst_matrix[f][c * 4];

			//las 2 "imagenes fuente", la segunda es la invertida
            bgra_t *p_sA = (bgra_t*) &src_matrix[f][c * 4];
            bgra_t *p_sB = (bgra_t*) &src_matrix[f][(cols - 1 - c )* 4];

            float auxb = ((alpha/255)*(p_sA->b - p_sB->b)) + p_sB->b;
            float auxg = ((alpha/255)*(p_sA->g - p_sB->g)) + p_sB->g;
            float auxr = ((alpha/255)*(p_sA->r - p_sB->r)) + p_sB->r;
            float auxa = ((alpha/255)*(p_sA->a - p_sB->a)) + p_sB->a;                                                

			p_d->b = auxb;
			p_d->g = auxg;
			p_d->r = auxr;
			p_d->a = auxa;

		}
	}
}
