
#ifndef __TEST__H__
#define __TEST__H__

#include <stdbool.h>

// ~~~ declaraciones de test ~~~
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned int uint;

typedef struct bgra_t {
	unsigned char b, g, r, a;
} __attribute__((packed)) bgra_t;

typedef struct bgra16_t {
	unsigned short b, g, r, a;
} __attribute__((packed)) bgra16_t;

typedef struct bgra32_t {
	unsigned int b, g, r, a;
} __attribute__((packed)) bgra32_t;



typedef struct bgr_t {
	unsigned char b, g, r;
} __attribute__((packed)) bgr_t;

typedef struct bgr16_t {
	unsigned short b, g, r;
} __attribute__((packed)) bgr16_t;

typedef struct bgr32_t {
	unsigned int b, g, r;
} __attribute__((packed)) bgr32_t;



extern void combinar_asm    (unsigned char *src, unsigned char *dst, int cols, int filas,
                      int src_row_size, int dst_row_size, float alpha);

extern void combinar_c    (unsigned char *src, unsigned char *dst, int cols, int filas,
                      int src_row_size, int dst_row_size, float alpha);

extern void combinar_co1    (unsigned char *src, unsigned char *dst, int cols, int filas,
                      int src_row_size, int dst_row_size, float alpha);

extern void combinar_co2    (unsigned char *src, unsigned char *dst, int cols, int filas,
                      int src_row_size, int dst_row_size, float alpha);

extern void combinar_co3    (unsigned char *src, unsigned char *dst, int cols, int filas,
                      int src_row_size, int dst_row_size, float alpha);

#endif   /* !__TEST__H__ */
