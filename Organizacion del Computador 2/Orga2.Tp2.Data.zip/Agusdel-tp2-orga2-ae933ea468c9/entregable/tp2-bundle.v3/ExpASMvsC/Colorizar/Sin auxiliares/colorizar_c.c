
#include "./test.h"

void colorizar_c (
	unsigned char *src,
	unsigned char *dst,
	int cols,
	int filas,
	int src_row_size,
	int dst_row_size,
	float alpha
) {
	unsigned char (*src_matrix)[src_row_size] = (unsigned char (*)[src_row_size]) src;
	unsigned char (*dst_matrix)[dst_row_size] = (unsigned char (*)[dst_row_size]) dst;

	for (int f = 1; f < filas - 1; f++) {
		for (int c = 1; c < cols - 1; c++) {
			bgra_t *p_d = (bgra_t*) &dst_matrix[f][c * 4];
            bgra_t *p_s = (bgra_t*) &src_matrix[f][c * 4];

            int maxr = 0;
            int maxb= 0;
            int maxg=0;

        	for (int fmax = f-1 ; fmax < f + 2; fmax++) {
				for (int cmax = c-1; cmax < c + 2; cmax++) {
					bgra_t *p_saux = (bgra_t*) &src_matrix[fmax][cmax * 4];
					maxr = maxr > p_saux->r ? maxr : p_saux->r;
					maxb = maxb > p_saux->b ? maxb : p_saux->b;
					maxg = maxg > p_saux->g ? maxg : p_saux->g;
				}
			}

			float deltar = (maxr >= maxg) && (maxr >= maxb) ? 1 + alpha: 1 - alpha; 
			float deltab = (maxr < maxb) && (maxg < maxb) ? 1 + alpha: 1 - alpha; 
			float deltag = (maxr < maxg) && (maxg >= maxb) ? 1 + alpha: 1 - alpha; 




			p_d->b = 255 < (deltab * p_d->b) ? 255 : (deltab * p_d->b);
			p_d->g = 255 < (deltag * p_d->g) ? 255 : (deltag * p_d->g);
			p_d->r = 255 < (deltar * p_d->r) ? 255 : (deltar * p_d->r);
			p_d->a = p_s->a;

		}
	}

}