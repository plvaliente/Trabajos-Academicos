#!/bin/bash

make clean

./generar_img_Lena.py 

make 

lscpu > cpu.data

./testLoop

echo
echo "GUARDO EN data.tar.gz:"
echo
tar -cvzf dataASMvsCPixelar.tar.gz *.data
echo
echo "EJECUTO CLEAN"
echo
make clean