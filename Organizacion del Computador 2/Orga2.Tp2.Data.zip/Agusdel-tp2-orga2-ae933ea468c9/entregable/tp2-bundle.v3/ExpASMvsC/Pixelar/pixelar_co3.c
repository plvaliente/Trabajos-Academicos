
#include "./test.h"

void pixelar_co3 (
	unsigned char *src, 
	unsigned char *dst, 
	int cols, 
	int filas, 
	int src_row_size, 
	int dst_row_size
) {
	unsigned char (*src_matrix)[src_row_size] = (unsigned char (*)[src_row_size]) src;
	unsigned char (*dst_matrix)[dst_row_size] = (unsigned char (*)[dst_row_size]) dst;

	for (int f = 0; f < filas; f = f + 2) {
		for (int c = 0; c < cols; c = c + 2) {

			//4 pixeles fuente
            bgra_t *p_s1 = (bgra_t*) &src_matrix[f][c * 4];
            bgra_t *p_s2 = (bgra_t*) &src_matrix[f][(c+1) * 4];
            bgra_t *p_s3 = (bgra_t*) &src_matrix[f+1][c * 4];
            bgra_t *p_s4 = (bgra_t*) &src_matrix[f+1][(c+1) * 4];            

            //4 pixeles destino
            bgra_t *p_d1 = (bgra_t*) &dst_matrix[f][c * 4];
            bgra_t *p_d2 = (bgra_t*) &dst_matrix[f][(c+1) * 4];
            bgra_t *p_d3 = (bgra_t*) &dst_matrix[f+1][c * 4];
            bgra_t *p_d4 = (bgra_t*) &dst_matrix[f+1][(c+1) * 4]; 

            //calculos los valores maximos de cada color
            int maxb = (p_s1->b + p_s2->b + p_s3->b + p_s4->b ) / 4 ;
            int maxg = (p_s1->g + p_s2->g + p_s3->g + p_s4->g ) / 4 ;
            int maxr = (p_s1->r + p_s2->r + p_s3->r + p_s4->r ) / 4 ;
            int maxa = (p_s1->a + p_s2->a + p_s3->a + p_s4->a ) / 4 ;

            //primer pixel

			p_d1->b = maxb;
			p_d1->g = maxg;
			p_d1->r = maxr;
			p_d1->a = maxa;

            //segundo pixel

			p_d2->b = maxb;
			p_d2->g = maxg;
			p_d2->r = maxr;
			p_d2->a = maxa;

            //tercer tercer

			p_d3->b = maxb;
			p_d3->g = maxg;
			p_d3->r = maxr;
			p_d3->a = maxa;

            //cuarto pixel

			p_d4->b = maxb;
			p_d4->g = maxg;
			p_d4->r = maxr;
			p_d4->a = maxa;									

		}
	}
}