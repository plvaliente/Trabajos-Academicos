
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "test.h"
#include "libbmp.h"

//void void colorizar_asm    (unsigned char *src, unsigned char *dst, int cols, int filas,
//          int src_row_size, int dst_row_size, float alpha);

// CARGA UNA IMAGEN Y LE APLICA Colorizar
// ESTA MAS COPADO PARA TESTEAR DESDE ACA
int comp (const void * elem1, const void * elem2) 
{
    long int f = *((long int*)elem1);
    long int s = *((long int*)elem2);
    if (f > s) return  1;
    if (f < s) return -1;
    return 0;
}

void testASM(){
	/**Archivos**/
	char* nMed = "mediana.ASM.data";
	FILE *medF = fopen( nMed, "a" );
	char* nMPod = "mediaPod.ASM.data";
	FILE *mPodF = fopen( nMPod, "a" );
	char* nMin = "minimo.ASM.data";
	FILE *minF = fopen( nMin, "a" );
	/**INICIALIZO ARREGLO**/
	long int *array = calloc(1000, sizeof *array);
	if (array == NULL){
    	printf ("FALLO ALLOC DEL ARREGLO \n");
	}
	/**IMGs A USAR**/
	char *imgE[9];
	imgE[0] = "./data/source.4x4.bmp";
	imgE[1] = "./data/source.16x16.bmp";
	imgE[2] = "./data/source.32x32.bmp";
	imgE[3] = "./data/source.64x64.bmp";
	imgE[4] = "./data/source.128x128.bmp";
	imgE[5] = "./data/source.256x256.bmp";
	imgE[6] = "./data/source.512x512.bmp";
	imgE[7] = "./data/source.1024x1024.bmp";
	imgE[8] = "./data/source.2048x2048.bmp";
	char *imgD[9];
	imgD[0] = "./data/dest.4x4.bmp";
	imgD[1] = "./data/dest.16x16.bmp";
	imgD[2] = "./data/dest.32x32.bmp";
	imgD[3] = "./data/dest.64x64.bmp";
	imgD[4] = "./data/dest.128x128.bmp";
	imgD[5] = "./data/dest.256x256.bmp";
	imgD[6] = "./data/dest.512x512.bmp";
	imgD[7] = "./data/dest.1024x1024.bmp";
	imgD[8] = "./data/dest.2048x2048.bmp";
	/**VARIABLES**/
	int cols;
	int filas;
	int src_row;
	int dst_row;
	int i;
	int k;
	/**LEO IMG**/
	for (k = 0; k < 9; ++k){ 
		BMP* in = bmp_read(imgE[k]);
		BMP* dest = bmp_read(imgD[k]);
		if (bmp_compression(in) == BI_RGB && bmp_compression(dest) == BI_RGB) {
			if (bmp_bit_count(in) == 24) {
	    		bmp_convert_24_to_32_bpp(in);
			}		
			if (bmp_bit_count(dest) == 24) {
	    		bmp_convert_24_to_32_bpp(dest);
			}
			uint8_t* src = bmp_data(in);
			uint8_t* dst = bmp_data(dest);
			switch(k) {
		      	case 0 :
		        	cols = 4;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 1 :
		        	cols = 16;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 2 :
		        	cols = 32;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 3 :
		        	cols = 64;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		      	case 4 :
		        	cols = 128;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 5 :
		        	cols = 256;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 6 :
		        	cols = 512;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 7 :
		        	cols = 1024;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 8 :
		        	cols = 2048;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		    }				
			for (i = 0; i < 1000; ++i){ //itero mil veces
				/**TIEMPO INIT**/
				clock_t tic = clock();
				/**FUN**/
				pixelar_asm(src, dst, cols, filas, src_row, dst_row);
				/**FUN**/
				tic = clock() - tic;
		 	 	/** TIEMPO FIN**/
		 	 	array[i] = tic;
		 	}
		 	/**GUARDO IMG Y LIBERO**/
			bmp_save(imgD[k], dest);
			bmp_delete(in);
			bmp_delete(dest);
		 	/**ORDENO ARRAY Y TOMO MEDIANA**/
			qsort(array, 1000, sizeof(array[0]), comp);
			fprintf (minF, "%ld \n", array[0]); //guardo minimo
			fprintf (medF, "%ld \n", array[499]); //guardo mediana
			long int media = 0;
			for (i = 0; i < 900; ++i){ // Genero Media Podada 10% a derecha
				media += array[i];
		 	}
		 	media = media/900;
		 	fprintf (mPodF, "%ld \n", media); //guardo media
		}		
	}
	/**LIBERO MEM**/
	free(array);
	fclose (medF);		
	fclose (minF);
	fclose (mPodF);
}

void testC(){
	/**Archivos**/
	char* nMed = "mediana.C.data";
	FILE *medF = fopen( nMed, "a" );
	char* nMPod = "mediaPod.C.data";
	FILE *mPodF = fopen( nMPod, "a" );
	char* nMin = "minimo.C.data";
	FILE *minF = fopen( nMin, "a" );
	/**INICIALIZO ARREGLO**/
	long int *array = calloc(1000, sizeof *array);
	if (array == NULL){
    	printf ("FALLO ALLOC DEL ARREGLO \n");
	}
	/**IMGs A USAR**/
	char *imgE[9];
	imgE[0] = "./data/source.4x4.bmp";
	imgE[1] = "./data/source.16x16.bmp";
	imgE[2] = "./data/source.32x32.bmp";
	imgE[3] = "./data/source.64x64.bmp";
	imgE[4] = "./data/source.128x128.bmp";
	imgE[5] = "./data/source.256x256.bmp";
	imgE[6] = "./data/source.512x512.bmp";
	imgE[7] = "./data/source.1024x1024.bmp";
	imgE[8] = "./data/source.2048x2048.bmp";
	char *imgD[9];
	imgD[0] = "./data/dest.4x4.bmp";
	imgD[1] = "./data/dest.16x16.bmp";
	imgD[2] = "./data/dest.32x32.bmp";
	imgD[3] = "./data/dest.64x64.bmp";
	imgD[4] = "./data/dest.128x128.bmp";
	imgD[5] = "./data/dest.256x256.bmp";
	imgD[6] = "./data/dest.512x512.bmp";
	imgD[7] = "./data/dest.1024x1024.bmp";
	imgD[8] = "./data/dest.2048x2048.bmp";
	/**VARIABLES**/
	int cols;
	int filas;
	int src_row;
	int dst_row;
	int i;
	int k;
	/**LEO IMG**/
	for (k = 0; k < 9; ++k){ 
		BMP* in = bmp_read(imgE[k]);
		BMP* dest = bmp_read(imgD[k]);
		if (bmp_compression(in) == BI_RGB && bmp_compression(dest) == BI_RGB) {
			if (bmp_bit_count(in) == 24) {
	    		bmp_convert_24_to_32_bpp(in);
			}		
			if (bmp_bit_count(dest) == 24) {
	    		bmp_convert_24_to_32_bpp(dest);
			}
			uint8_t* src = bmp_data(in);
			uint8_t* dst = bmp_data(dest);
			switch(k) {
		      	case 0 :
		        	cols = 4;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 1 :
		        	cols = 16;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 2 :
		        	cols = 32;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 3 :
		        	cols = 64;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		      	case 4 :
		        	cols = 128;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 5 :
		        	cols = 256;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 6 :
		        	cols = 512;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 7 :
		        	cols = 1024;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 8 :
		        	cols = 2048;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		    }				
			for (i = 0; i < 1000; ++i){ //itero mil veces
				/**TIEMPO INIT**/
				clock_t tic = clock();
				/**FUN**/
				pixelar_c(src, dst, cols, filas, src_row, dst_row);
				/**FUN**/
				tic = clock() - tic;
		 	 	/** TIEMPO FIN**/
		 	 	array[i] = tic;
		 	}
		 	/**GUARDO IMG Y LIBERO**/
			bmp_save(imgD[k], dest);
			bmp_delete(in);
			bmp_delete(dest);
		 	/**ORDENO ARRAY Y TOMO MEDIANA**/
			qsort(array, 1000, sizeof(array[0]), comp);
			fprintf (minF, "%ld \n", array[0]); //guardo minimo
			fprintf (medF, "%ld \n", array[499]); //guardo mediana
			long int media = 0;
			for (i = 0; i < 900; ++i){ // Genero Media Podada 10% a derecha
				media += array[i];
		 	}
		 	media = media/900;
		 	fprintf (mPodF, "%ld \n", media); //guardo media
		}		
	}
	/**LIBERO MEM**/
	free(array);
	fclose (medF);		
	fclose (minF);
	fclose (mPodF);
}

void testCo1(){
	/**Archivos**/
	char* nMed = "mediana.Co1.data";
	FILE *medF = fopen( nMed, "a" );
	char* nMPod = "mediaPod.Co1.data";
	FILE *mPodF = fopen( nMPod, "a" );
	char* nMin = "minimo.Co1.data";
	FILE *minF = fopen( nMin, "a" );
	/**INICIALIZO ARREGLO**/
	long int *array = calloc(1000, sizeof *array);
	if (array == NULL){
    	printf ("FALLO ALLOC DEL ARREGLO \n");
	}
	/**IMGs A USAR**/
	char *imgE[9];
	imgE[0] = "./data/source.4x4.bmp";
	imgE[1] = "./data/source.16x16.bmp";
	imgE[2] = "./data/source.32x32.bmp";
	imgE[3] = "./data/source.64x64.bmp";
	imgE[4] = "./data/source.128x128.bmp";
	imgE[5] = "./data/source.256x256.bmp";
	imgE[6] = "./data/source.512x512.bmp";
	imgE[7] = "./data/source.1024x1024.bmp";
	imgE[8] = "./data/source.2048x2048.bmp";
	char *imgD[9];
	imgD[0] = "./data/dest.4x4.bmp";
	imgD[1] = "./data/dest.16x16.bmp";
	imgD[2] = "./data/dest.32x32.bmp";
	imgD[3] = "./data/dest.64x64.bmp";
	imgD[4] = "./data/dest.128x128.bmp";
	imgD[5] = "./data/dest.256x256.bmp";
	imgD[6] = "./data/dest.512x512.bmp";
	imgD[7] = "./data/dest.1024x1024.bmp";
	imgD[8] = "./data/dest.2048x2048.bmp";
	/**VARIABLES**/
	int cols;
	int filas;
	int src_row;
	int dst_row;
	int i;
	int k;
	/**LEO IMG**/
	for (k = 0; k < 9; ++k){ 
		BMP* in = bmp_read(imgE[k]);
		BMP* dest = bmp_read(imgD[k]);
		if (bmp_compression(in) == BI_RGB && bmp_compression(dest) == BI_RGB) {
			if (bmp_bit_count(in) == 24) {
	    		bmp_convert_24_to_32_bpp(in);
			}		
			if (bmp_bit_count(dest) == 24) {
	    		bmp_convert_24_to_32_bpp(dest);
			}
			uint8_t* src = bmp_data(in);
			uint8_t* dst = bmp_data(dest);
			switch(k) {
		      	case 0 :
		        	cols = 4;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 1 :
		        	cols = 16;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 2 :
		        	cols = 32;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 3 :
		        	cols = 64;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		      	case 4 :
		        	cols = 128;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 5 :
		        	cols = 256;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 6 :
		        	cols = 512;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 7 :
		        	cols = 1024;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 8 :
		        	cols = 2048;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		    }				
			for (i = 0; i < 1000; ++i){ //itero mil veces
				/**TIEMPO INIT**/
				clock_t tic = clock();
				/**FUN**/
				pixelar_co1(src, dst, cols, filas, src_row, dst_row);
				/**FUN**/
				tic = clock() - tic;
		 	 	/** TIEMPO FIN**/
		 	 	array[i] = tic;
		 	}
		 	/**GUARDO IMG Y LIBERO**/
			bmp_save(imgD[k], dest);
			bmp_delete(in);
			bmp_delete(dest);
		 	/**ORDENO ARRAY Y TOMO MEDIANA**/
			qsort(array, 1000, sizeof(array[0]), comp);
			fprintf (minF, "%ld \n", array[0]); //guardo minimo
			fprintf (medF, "%ld \n", array[499]); //guardo mediana
			long int media = 0;
			for (i = 0; i < 900; ++i){ // Genero Media Podada 10% a derecha
				media += array[i];
		 	}
		 	media = media/900;
		 	fprintf (mPodF, "%ld \n", media); //guardo media
		}		
	}
	/**LIBERO MEM**/
	free(array);
	fclose (medF);		
	fclose (minF);
	fclose (mPodF);
}


void testCo2(){
	/**Archivos**/
	char* nMed = "mediana.Co2.data";
	FILE *medF = fopen( nMed, "a" );
	char* nMPod = "mediaPod.Co2.data";
	FILE *mPodF = fopen( nMPod, "a" );
	char* nMin = "minimo.Co2.data";
	FILE *minF = fopen( nMin, "a" );
	/**INICIALIZO ARREGLO**/
	long int *array = calloc(1000, sizeof *array);
	if (array == NULL){
    	printf ("FALLO ALLOC DEL ARREGLO \n");
	}
	/**IMGs A USAR**/
	char *imgE[9];
	imgE[0] = "./data/source.4x4.bmp";
	imgE[1] = "./data/source.16x16.bmp";
	imgE[2] = "./data/source.32x32.bmp";
	imgE[3] = "./data/source.64x64.bmp";
	imgE[4] = "./data/source.128x128.bmp";
	imgE[5] = "./data/source.256x256.bmp";
	imgE[6] = "./data/source.512x512.bmp";
	imgE[7] = "./data/source.1024x1024.bmp";
	imgE[8] = "./data/source.2048x2048.bmp";
	char *imgD[9];
	imgD[0] = "./data/dest.4x4.bmp";
	imgD[1] = "./data/dest.16x16.bmp";
	imgD[2] = "./data/dest.32x32.bmp";
	imgD[3] = "./data/dest.64x64.bmp";
	imgD[4] = "./data/dest.128x128.bmp";
	imgD[5] = "./data/dest.256x256.bmp";
	imgD[6] = "./data/dest.512x512.bmp";
	imgD[7] = "./data/dest.1024x1024.bmp";
	imgD[8] = "./data/dest.2048x2048.bmp";
	/**VARIABLES**/
	int cols;
	int filas;
	int src_row;
	int dst_row;
	int i;
	int k;
	/**LEO IMG**/
	for (k = 0; k < 9; ++k){ 
		BMP* in = bmp_read(imgE[k]);
		BMP* dest = bmp_read(imgD[k]);
		if (bmp_compression(in) == BI_RGB && bmp_compression(dest) == BI_RGB) {
			if (bmp_bit_count(in) == 24) {
	    		bmp_convert_24_to_32_bpp(in);
			}		
			if (bmp_bit_count(dest) == 24) {
	    		bmp_convert_24_to_32_bpp(dest);
			}
			uint8_t* src = bmp_data(in);
			uint8_t* dst = bmp_data(dest);
			switch(k) {
		      	case 0 :
		        	cols = 4;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 1 :
		        	cols = 16;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 2 :
		        	cols = 32;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 3 :
		        	cols = 64;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		      	case 4 :
		        	cols = 128;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 5 :
		        	cols = 256;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 6 :
		        	cols = 512;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 7 :
		        	cols = 1024;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 8 :
		        	cols = 2048;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		    }				
			for (i = 0; i < 1000; ++i){ //itero mil veces
				/**TIEMPO INIT**/
				clock_t tic = clock();
				/**FUN**/
				pixelar_co2(src, dst, cols, filas, src_row, dst_row);
				/**FUN**/
				tic = clock() - tic;
		 	 	/** TIEMPO FIN**/
		 	 	array[i] = tic;
		 	}
		 	/**GUARDO IMG Y LIBERO**/
			bmp_save(imgD[k], dest);
			bmp_delete(in);
			bmp_delete(dest);
		 	/**ORDENO ARRAY Y TOMO MEDIANA**/
			qsort(array, 1000, sizeof(array[0]), comp);
			fprintf (minF, "%ld \n", array[0]); //guardo minimo
			fprintf (medF, "%ld \n", array[499]); //guardo mediana
			long int media = 0;
			for (i = 0; i < 900; ++i){ // Genero Media Podada 10% a derecha
				media += array[i];
		 	}
		 	media = media/900;
		 	fprintf (mPodF, "%ld \n", media); //guardo media
		}		
	}
	/**LIBERO MEM**/
	free(array);
	fclose (medF);		
	fclose (minF);
	fclose (mPodF);
}


void testCo3(){
	/**Archivos**/
	char* nMed = "mediana.Co3.data";
	FILE *medF = fopen( nMed, "a" );
	char* nMPod = "mediaPod.Co3.data";
	FILE *mPodF = fopen( nMPod, "a" );
	char* nMin = "minimo.Co3.data";
	FILE *minF = fopen( nMin, "a" );
	/**INICIALIZO ARREGLO**/
	long int *array = calloc(1000, sizeof *array);
	if (array == NULL){
    	printf ("FALLO ALLOC DEL ARREGLO \n");
	}
	/**IMGs A USAR**/
	char *imgE[9];
	imgE[0] = "./data/source.4x4.bmp";
	imgE[1] = "./data/source.16x16.bmp";
	imgE[2] = "./data/source.32x32.bmp";
	imgE[3] = "./data/source.64x64.bmp";
	imgE[4] = "./data/source.128x128.bmp";
	imgE[5] = "./data/source.256x256.bmp";
	imgE[6] = "./data/source.512x512.bmp";
	imgE[7] = "./data/source.1024x1024.bmp";
	imgE[8] = "./data/source.2048x2048.bmp";
	char *imgD[9];
	imgD[0] = "./data/dest.4x4.bmp";
	imgD[1] = "./data/dest.16x16.bmp";
	imgD[2] = "./data/dest.32x32.bmp";
	imgD[3] = "./data/dest.64x64.bmp";
	imgD[4] = "./data/dest.128x128.bmp";
	imgD[5] = "./data/dest.256x256.bmp";
	imgD[6] = "./data/dest.512x512.bmp";
	imgD[7] = "./data/dest.1024x1024.bmp";
	imgD[8] = "./data/dest.2048x2048.bmp";
	/**VARIABLES**/
	int cols;
	int filas;
	int src_row;
	int dst_row;
	int i;
	int k;
	/**LEO IMG**/
	for (k = 0; k < 9; ++k){ 
		BMP* in = bmp_read(imgE[k]);
		BMP* dest = bmp_read(imgD[k]);
		if (bmp_compression(in) == BI_RGB && bmp_compression(dest) == BI_RGB) {
			if (bmp_bit_count(in) == 24) {
	    		bmp_convert_24_to_32_bpp(in);
			}		
			if (bmp_bit_count(dest) == 24) {
	    		bmp_convert_24_to_32_bpp(dest);
			}
			uint8_t* src = bmp_data(in);
			uint8_t* dst = bmp_data(dest);
			switch(k) {
		      	case 0 :
		        	cols = 4;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 1 :
		        	cols = 16;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 2 :
		        	cols = 32;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 3 :
		        	cols = 64;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		      	case 4 :
		        	cols = 128;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 5 :
		        	cols = 256;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 6 :
		        	cols = 512;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 7 :
		        	cols = 1024;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		        case 8 :
		        	cols = 2048;
					filas = cols;
					src_row = cols*4;
					dst_row = src_row;
		        	break;
		    }				
			for (i = 0; i < 1000; ++i){ //itero mil veces
				/**TIEMPO INIT**/
				clock_t tic = clock();
				/**FUN**/
				pixelar_co3(src, dst, cols, filas, src_row, dst_row);
				/**FUN**/
				tic = clock() - tic;
		 	 	/** TIEMPO FIN**/
		 	 	array[i] = tic;
		 	}
		 	/**GUARDO IMG Y LIBERO**/
			bmp_save(imgD[k], dest);
			bmp_delete(in);
			bmp_delete(dest);
		 	/**ORDENO ARRAY Y TOMO MEDIANA**/
			qsort(array, 1000, sizeof(array[0]), comp);
			fprintf (minF, "%ld \n", array[0]); //guardo minimo
			fprintf (medF, "%ld \n", array[499]); //guardo mediana
			long int media = 0;
			for (i = 0; i < 900; ++i){ // Genero Media Podada 10% a derecha
				media += array[i];
		 	}
		 	media = media/900;
		 	fprintf (mPodF, "%ld \n", media); //guardo media
		}		
	}
	/**LIBERO MEM**/
	free(array);
	fclose (medF);		
	fclose (minF);
	fclose (mPodF);
}

int main() {

	testASM();
	testC();
	testCo1();
	testCo2();
	testCo3();


	return 0;
}