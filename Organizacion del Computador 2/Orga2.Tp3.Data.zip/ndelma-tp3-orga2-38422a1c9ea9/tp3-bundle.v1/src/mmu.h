/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del manejador de memoria
*/

#ifndef __MMU_H__
#define __MMU_H__

#include "i386.h"
//#include "stdio.h"
#include "defines.h"



#define DIR_PAG_ADDR 0x27000

#define DIR_TBL1_ADDR 0x28000
#define DIR_TBL2_ADDR 0x30000

#define PDE_INDEX(virtual) (virtual >> 22)
#define PTE_INDEX(virtual) ((virtual << 10) >> 22)
#define ALIGN(dir) (dir & 0xFFFFF000)
#define OFFSET(dir) (dir & 0x00000FFF)

#define PG_PRESENT 1
#define PG_READ_WRITE 2
#define PGUSER 4
#define PRESENT_RW 3  
#define PRESENT_RW_USER 7

typedef struct directorio{
	unsigned int tablas_b_0_31[1024];
} __attribute__((__packed__)) directorio;


typedef struct tabla{
	unsigned int paginas_b_0_31[1024];
} __attribute__((__packed__)) tabla;

unsigned int mmu_inicializar_dir_tarea(unsigned int dirTarea);
unsigned int prox_pag_libre();
void mmu_mapear_pagina(unsigned int virtual, unsigned int cr3, unsigned int fisica, unsigned int attr);
void mmu_unmapear_pagina(unsigned int virtual, unsigned int cr3);
void mmu_copiar_y_mapear(unsigned int virtual, unsigned int cr3, unsigned int fisicaNueva, unsigned int attr);
unsigned int obtener_fisica(unsigned int cr3, unsigned int logica);

#endif	/* !__MMU_H__ */
