/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de las rutinas de atencion de interrupciones
*/

#ifndef __ISR_H__
#define __ISR_H__

#define min(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a < _b ? _a : _b; })

#include "mmu.h"
#include "sched.h"
#include "screen.h"
#include "defines.h"
#include "i386.h"

char* misil;
char* obj;
unsigned int rango;
unsigned short nrotar;


void _isr0();
void _isr1();
void _isr2();
void _isr3();
void _isr4();
void _isr5();
void _isr6();
void _isr7();
void _isr8();
void _isr9();
void _isr10();
void _isr11();
void _isr12();
void _isr13();
void _isr14();
//void _isr15(); intel reserved dont use
void _isr16();
void _isr17();
void _isr18();
void _isr19();
//interrupciones de teclado y reloj
void _isr32();
void _isr33();
//interrupciones de software
void _isr80();
void _isr102();
// imprime en pantalla registros y excepcion-navio
void mostrar_estado_error();

void atender_syscall(unsigned int cr3Tarea, unsigned int interr, unsigned int objetivo1, unsigned int objetivo2){
	if (!soybandera()){
		switch (interr){
			// INTERRUPCION TIRAR ANCLA
			case 0x923:

				if (objetivo1 <= AREA_TIERRA_FIN){
					mmu_unmapear_pagina(0x40002000,cr3Tarea);
					screen_anclar(obtener_fisica(cr3Tarea, 0x40002000), objetivo1, ejecucionactual());
					mmu_mapear_pagina(0x40002000,cr3Tarea,objetivo1,(PGUSER | PG_PRESENT));
				}else{
					//tiro ancla a un lugar incorrecto, desalojo?
					mostrar_estado_error();
					print_Excepciones(20, ejecucionactual());
					eliminar_tarea(ejecucionactual());				
				}
				break;
			// INTERRUPCION LANZAR MISIL
			case 0x83A:
				//char misil[97];
			
			if(AREA_MAR_INICIO <= objetivo1 &&
			objetivo1 <= AREA_MAR_FIN) {
				
					obj = (char*) objetivo1;
					misil = (char*)objetivo2;
					//rango = min(97, AREA_MAR_FIN - objetivo1 + 1);
		
					for (unsigned int i = 0; i < 97; i++){
						obj[i] = misil[i];
					}
					//pinto el mapa con el misil
					screen_misil(objetivo1);

				}else{
					//disparo a un lugar incorrecto, desalojo?
					mostrar_estado_error();
					print_Excepciones(21, ejecucionactual());
					eliminar_tarea(ejecucionactual());
				}
			
				break;
			// INTERRUPCION NAVEGAR
			case 0xAEF:
			if(AREA_MAR_INICIO <= objetivo1 &&
			objetivo1 <= AREA_MAR_FIN && AREA_MAR_INICIO <= objetivo2 &&
			objetivo2 <= AREA_MAR_FIN){

					screen_navegar(obtener_fisica(cr3Tarea, 0x40000000), objetivo1, tareaactual());
					screen_navegar(obtener_fisica(cr3Tarea, 0x40001000), objetivo2, tareaactual());
					mmu_copiar_y_mapear(0x40000000,cr3Tarea,objetivo1,PRESENT_RW_USER);
					mmu_copiar_y_mapear(0x40001000,cr3Tarea,objetivo2,PRESENT_RW_USER);
					//Actualizo estado de paginacion de tareas
					actualizar_estado_tarea(tareaactual(),1, objetivo1);
					actualizar_estado_tarea(tareaactual(),2, objetivo2);
				}else{
					//navego a lugar incorrecto, desalojo?
					mostrar_estado_error();
					print_Excepciones(22, ejecucionactual());
					eliminar_tarea(ejecucionactual());	
				}
				break;

			default:
				//syscall invalida, desalojo?
				mostrar_estado_error();
				print_Excepciones(23, ejecucionactual());
				eliminar_tarea(ejecucionactual());	
			}
	}else{
		//la bandera no puede hacer syscall por lo que se desaloja la tarea
		mostrar_estado_error();
		print_Excepciones(24, ejecucionactual());
		eliminar_tarea(ejecucionactual());

	}
}

void atender_syscall66(unsigned int dir_bandera_buffer){
	nrotar = ejecucionactual();
	if (soybandera()){
		pintar_bandera(nrotar, dir_bandera_buffer);
	}else{
		mostrar_estado_error();
		print_Excepciones(25, ejecucionactual());
		eliminar_tarea(nrotar);
	}
}
//static screen_elem (*pantalla)[VIDEO_COLS] = (screen_elem (*)[VIDEO_COLS]) VIDEO_ADDR;
#endif  /* !__ISR_H__ */
