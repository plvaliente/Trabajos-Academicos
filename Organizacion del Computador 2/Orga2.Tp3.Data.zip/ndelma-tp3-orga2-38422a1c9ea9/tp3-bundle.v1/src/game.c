/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
*/

#include "game.h"

unsigned int game_fondear(unsigned int ancla_dir_fisica) {
    return TRUE;
}

unsigned int game_canonear(unsigned int dir_misil_fisica, unsigned int dir_buffer_absoluta) {
    return TRUE;
}

unsigned int game_navegar(unsigned int dir_primera_pag_fisica, unsigned int dir_segunda_pag_fisica) {
    return TRUE;
}
