/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================

    Definiciones globales del sistema.
*/

#ifndef __DEFINES_H__
#define __DEFINES_H__

/* Bool */
/* -------------------------------------------------------------------------- */
#define TRUE                    0x00000001
#define FALSE                   0x00000000


/* Misc */
/* -------------------------------------------------------------------------- */
#define CANT_TAREAS             8

#define TAMANO_PAGINA           0x00001000

#define TASK_SIZE               2 * 4096

/* Indices en la gdt */
/* -------------------------------------------------------------------------- */
#define GDT_IDX_NULL_DESC           0
#define GDT_IDX_CODE_LVL0           18
#define GDT_IDX_CODE_LVL3           19
#define GDT_IDX_DATA_LVL0           20 
#define GDT_IDX_DATA_LVL3           21
#define GDT_VIDEO                   22

#define GDT_IDX_TAREA_1				2
#define GDT_IDX_BANDERA_1			3
#define GDT_IDX_TAREA_2				4
#define GDT_IDX_BANDERA_2			5
#define GDT_IDX_TAREA_3				6
#define GDT_IDX_BANDERA_3			7
#define GDT_IDX_TAREA_4				8
#define GDT_IDX_BANDERA_4			9
#define GDT_IDX_TAREA_5				10
#define GDT_IDX_BANDERA_5			11
#define GDT_IDX_TAREA_6				12
#define GDT_IDX_BANDERA_6			13
#define GDT_IDX_TAREA_7				14
#define GDT_IDX_BANDERA_7			15
#define GDT_IDX_TAREA_8				16
#define GDT_IDX_BANDERA_8			17

#define GDT_IDX_TAREA_IDLE			1
#define GDT_IDX_TAREA_INICIAL		23

/* Direcciones de memoria */
/* -------------------------------------------------------------------------- */
#define BOOTSECTOR              0x00001000 /* direccion fisica de comienzo del bootsector (copiado) */
#define KERNEL                  0x00001200 /* direccion fisica de comienzo del kernel */
#define VIDEO                   0x000B8000 /* direccion fisica del buffer de video */

/* Direcciones virtuales de código, pila y datos */
/* -------------------------------------------------------------------------- */
#define TASK_CODE               0x40000000 /* direccion virtual del codigo */

#define TASK_IDLE_CODE          0x40000000 /* direccion virtual del codigo de la tarea idle */
#define TASK_IDLE_STACK         0x003D0000 /* direccion virtual de la pila de la tarea idle */
#define TASK_IDLE_STACK_RING_0  0x0002B000 /* direccion fisica de la pila de la tarea idle */

#define TASK_ANCLA              0x40002000
#define TASK_ANCLA_FIS          0x00000000

#define AREA_TIERRA_INICIO      0x00000000  /* 0.0 MB     */
#define AREA_TIERRA_FIN         0x000FFFFF  /* 1.0 MB - 1 */
#define AREA_MAR_INICIO         0x00100000  /* 1.0 MB     */
#define AREA_MAR_FIN            0x0077FFFF  /* 7.5 MB - 1 */

/* Direcciones fisicas de codigos */
/* -------------------------------------------------------------------------- */
/* En estas direcciones estan los códigos de todas las tareas. De aqui se
 * copiaran al destino indicado por TASK_<i>_CODE_ADDR.
 */
#define TASK_1_CODE_SRC_ADDR    0x00010000
#define TASK_2_CODE_SRC_ADDR    0x00012000
#define TASK_3_CODE_SRC_ADDR    0x00014000
#define TASK_4_CODE_SRC_ADDR    0x00016000
#define TASK_5_CODE_SRC_ADDR    0x00018000
#define TASK_6_CODE_SRC_ADDR    0x0001A000
#define TASK_7_CODE_SRC_ADDR    0x0001C000
#define TASK_8_CODE_SRC_ADDR    0x0001E000
#define TASK_CODE_SRC_ADDR(num)	0x00010000 + (num * 0x2000)

#define TASK_1_CODE_SRC_ADDR    0x00010000
#define TASK_2_CODE_SRC_ADDR    0x00012000
#define TASK_3_CODE_SRC_ADDR    0x00014000
#define TASK_4_CODE_SRC_ADDR    0x00016000
#define TASK_5_CODE_SRC_ADDR    0x00018000
#define TASK_6_CODE_SRC_ADDR    0x0001A000
#define TASK_7_CODE_SRC_ADDR    0x0001C000

#define TAREA_1_MAR_P1    		0x00150000
#define TAREA_1_MAR_P2    		0x00151000

#define TAREA_2_MAR_P1    		0x00120000
#define TAREA_2_MAR_P2    		0x00121000

#define TAREA_3_MAR_P1    		0x00500000
#define TAREA_3_MAR_P2    		0x00501000

#define TAREA_4_MAR_P1    		0x00200000
#define TAREA_4_MAR_P2    		0x00201000

#define TAREA_5_MAR_P1    		0x00600000
#define TAREA_5_MAR_P2    		0x00601000

#define TAREA_6_MAR_P1    		0x00400000
#define TAREA_6_MAR_P2    		0x00401000

#define TAREA_7_MAR_P1    		0x00160000
#define TAREA_7_MAR_P2    		0x00161000

#define TAREA_8_MAR_P1    		0x00100000
#define TAREA_8_MAR_P2    		0x00101000

#define TASK_IDLE_CODE_SRC_ADDR 0x00020000

#endif  /* !__DEFINES_H__ */
