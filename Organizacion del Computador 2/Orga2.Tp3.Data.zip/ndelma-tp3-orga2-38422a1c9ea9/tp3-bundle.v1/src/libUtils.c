/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones utiles
*/

#include "libUtils.h"

/******** SEMILLAS ********/
static unsigned int a = INIT_PRIME_A;
static unsigned int c = INIT_PRIME_C;
static unsigned int x = INIT_PRIME_X;
static unsigned int m = INIT_MOD_M;

unsigned int randPseudo(unsigned int value){ 
    unsigned int r = ((a*x)+c)%m;
    switch(value % 3){ 
        case 0:
            if(value < 6){
        		a = r;	
        	}
        	else{
        		a = r/5;
        	}
        	break;
        case 1:
        	if(value < 6){
        		c = r;	
        	}
        	else{
        		c = r/2;
        	}
            break;
        case 2:
            if(value < 6){
        		x = r;	
        	}
        	else{
        		x = r/3;
        	}
        	break;
    }
    /******** PROTECCION CONTRA 0 ********/
    if(a == 0){
    	a = INIT_PRIME_X;
    }
    if(x == 0){
    	x = INIT_PRIME_C;
    }

    return r;
}




