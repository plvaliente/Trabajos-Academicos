/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del scheduler
*/

#include "screen.h"
#include "colors.h"
#include "libUtils.h"
//#include "stdlib.h"     /* srand, rand */


//#define VIDEO_FILS 25
//#define VIDEO_COLS 80
 #define Nombre_Grupo "Enrique Jan - Planetario"
 #define numeros "12345678"

static unsigned int modo_estado = 1;
static unsigned int dir_ult_misil = 0;

static screen_elem buffer_estado [VIDEO_FILS][VIDEO_COLS];
static screen_elem buffer_mapa [VIDEO_FILS][VIDEO_COLS];
static screen_elem (*pantalla)[VIDEO_COLS] = (screen_elem (*)[VIDEO_COLS]) VIDEO_ADDR;
static screen_elem (*bandera_desalojada)[10];

static char* excepciones[26] = {"Divide Error", "RESERVED", "NMI Interrupt", "Breakpoint", "Overflow", "BOUND Range Exceeded", "Invalid Opcode", "Device Not Available", "Double Fault", "Coprocessor Segment Overrun", "Invalid TSS", "Segment Not Present", "Stack-Segment Fault", "General Protection", "Page Fault","NOT IN USE", "x87 FPU Floating-Point Error", "Alignment Check", "Machine Check", "SIMD Floating-Point Exception", "Syscall Ancla Error", "Syscall Misil Error", "Syscall Navegar Error", "Syscall Invalida",  "Error Bandera Int 0x50", "Error Tarea Int 0x66" };
static char* nom_reg[20] = {"EFLAGS", "SS", "GS", "FS", "ES", "DS", "CS", "CR4", "CR3", "CR2", "CR0", "EIP", "EDI", "ESI", "EBP", "ESP", "EBX", "EDX", "ECX", "EAX" };

void cambiar_primercaracter(){
	screen_elem rojo;
	rojo._char = '0';
	rojo._mode = C_BG_RED | C_FG_RED;
	pantalla[0][0] = rojo;
}

void numero_Color_Rnd(unsigned int value, int n){
	screen_elem numero;
	numero._char = (n + 48); // pasamos a ASCII
	numero._mode = ((randPseudo(value)%8) << 4) | C_FG_WHITE;
	buffer_estado[0][79] = numero;
	buffer_mapa[0][79] = numero;
	if(modo_estado){
		screen_imprimir_estado();
	}else{
		screen_imprimir_mapa();
	}
}

void imprimir_nombres(){
int x = 5;
int y = 2;
print_string("NAVIO 1", x, y, C_BG_LIGHT_GREY | C_FG_BLACK);
x += 12;
print_string("NAVIO 2", x, y, C_BG_LIGHT_GREY | C_FG_BLACK);
x += 12;
print_string("NAVIO 3", x, y, C_BG_LIGHT_GREY | C_FG_BLACK);
x += 12;
print_string("NAVIO 4", x, y, C_BG_LIGHT_GREY | C_FG_BLACK);
x = 5;
y=9;
print_string("NAVIO 5", x, y, C_BG_LIGHT_GREY | C_FG_BLACK);
x += 12;
print_string("NAVIO 6", x, y, C_BG_LIGHT_GREY | C_FG_BLACK);
x += 12;
print_string("NAVIO 7", x, y, C_BG_LIGHT_GREY | C_FG_BLACK);
x += 12;
print_string("NAVIO 8", x, y, C_BG_LIGHT_GREY | C_FG_BLACK);


}

void crear_banderas(bandera banderas[]){
	bandera b1;
	screen_elem rojo;
	rojo._char = '0';
	rojo._mode = C_BG_RED | C_FG_RED;
	for (int f = 0; f < 5; f++){
		for(int c = 0; c < 10; c++){
			b1.band_chars[f][c] = rojo;
		}
	}
	banderas[0]= b1;
}

//screen_elem band_chars[5][10]

void imprimir_bandera(bandera b, unsigned int x , unsigned int y){
	int i = 0;
	int j = 0;

    for (int f = x; f < x + 5; f++) {
    	j=0;
    	for(int c = y; c < y + 10; c++){
    		pantalla[f][c] = b.band_chars[i][j];
    		j++;
    	}

    }
}

void iniciar_banderas(){
	bandera b;
	screen_elem negro;
	negro._char = '0';
	negro._mode = C_BG_BLACK | C_FG_BLACK;
	screen_elem cruz;
	cruz._char = 'X';
	cruz._mode = C_BG_BLUE | C_FG_WHITE;
	for (int f = 0; f < 5; f++){
		for(int c = 0; c < 10; c++){
			b.band_chars[f][c] = negro;
			bandera_desalojada[f][c] = cruz;
		}
	}
	int x = 3;
	int y = 2;
	for(int i = 0; i < 8; i++){
		imprimir_bandera(b, x, y);	
		y += 12;
		if(i == 3){
			x = 10;
			y = 2;
		}
	}
	
}

 void screen_pintar_pantalla(){
 	screen_elem elemento;
	elemento._char = '0';
	elemento._mode = C_BG_BLACK | C_FG_BLACK;
	screen_elem elementoBl;
	elementoBl._char = '0';
	elementoBl._mode = C_BG_BLACK | C_FG_WHITE;
	
	for(int c = 0; c < VIDEO_COLS; c++){
		pantalla[0][c] = elementoBl;
	}	
	for(int f = 1; f < VIDEO_FILS - 1; f++ ){
		
		for(int c = 0; c < VIDEO_COLS; c++){
			pantalla[f][c] = elemento;
		}
	}
	for(int c = 0; c < VIDEO_COLS; c++){
		pantalla[VIDEO_FILS - 1][c] = elementoBl;
	}
}

 void print_Excepciones(unsigned int error, unsigned int num_tarea){
  	screen_elem celeste;
	celeste._char = '0';
	celeste._mode = C_BG_CYAN | C_FG_CYAN;

	for (int i = 50; i < 78; i++){
		buffer_estado[1][i] = celeste;

	}

	//imprimo error y navio que lo produjo
	const char * str_error = excepciones[error];
	print_string_buffer(str_error, 50, 1, (C_BG_CYAN | C_FG_BLACK));
    print_string_buffer("NAVIO", 71, 1, (C_BG_CYAN | C_FG_BLACK));
    print_int_buffer(num_tarea, 77, 1, (C_BG_CYAN | C_FG_BLACK));
    
    // "tacho" la tarea en estados y pongo el error
	for (int j = 2; j < 79; j++){
		if (j != 2 && j != 16 && j != 30 && j <= 43){
			buffer_estado[15 + num_tarea][j]._mode = (C_BG_RED | C_FG_WHITE);  
		}else{
			buffer_estado[15 + num_tarea][j]._mode = (C_BG_RED | C_FG_RED);  
		}
	}	
	print_string_buffer(str_error, 50, (15 + num_tarea), (C_BG_RED | C_FG_WHITE));
    
    if (modo_estado){
    	screen_imprimir_estado();
    }
}

void screen_imprimir_grupo(){
	screen_elem negro;
	negro._char = '0';
	negro._mode = C_BG_BLACK | C_FG_BLACK;

	for(int c = 0; c < VIDEO_COLS; c++){
		if(c == 1){
			int j = 0;
			while(Nombre_Grupo[j] != 0){
				screen_elem charExc;
				charExc._char = Nombre_Grupo[j];
				charExc._mode = C_BG_BLACK | C_FG_MAGENTA;	
				pantalla[0][c] = charExc;
				j++;
				c++;
			}
			pantalla[0][c] = negro;
		}
		else{
			pantalla[0][c] = negro;
		}	
	}	
	for(int f = 1; f < VIDEO_FILS ; f++ ){
		for(int c = 0; c < VIDEO_COLS; c++){
			pantalla[f][c] = negro;
		}
	}

}

void screen_imprimir_mapa_inicial(){
 	screen_elem tierra;
	tierra._char = '0';
	tierra._mode = C_BG_GREEN | C_FG_GREEN;
	screen_elem agua;
	agua._char = '0';
	agua._mode = C_BG_CYAN | C_FG_CYAN;
	screen_elem elementoBl;
	elementoBl._char = '0';
	elementoBl._mode = C_BG_BLACK | C_FG_BLACK;
	
	for(int c = 0; c < VIDEO_COLS; c++){
		pantalla[0][c] = tierra;
		pantalla[1][c] = tierra;
		pantalla[2][c] = tierra;
	}

	for(int c = 0; c < VIDEO_COLS; c++){
		if (c < 16){
			pantalla[3][c] = tierra;
		}else{
			pantalla[3][c] = agua;
		}	
	}
	for(int f = 4; f < VIDEO_FILS -1 ; f++ ){
		for(int c = 0; c < VIDEO_COLS; c++){
			pantalla[f][c] = agua;
		}
	}



	for(int c = 0; c < VIDEO_COLS; c++){
		pantalla[VIDEO_FILS - 1][c] = elementoBl;
	}

	//las tareas de la ultima linea
	screen_tareas_en_ejecucion_inicial();

	//guardo mapa inicial en buffer
	for (int i = 0; i < 25; i++){
		for (int j = 0; j<80; j++){
			buffer_mapa[i][j] = pantalla[i][j];
		}
	}
}

void screen_imprimir_mapa(){
	//actualizo mapa con lo que hay en el buffer
	for (int i = 0; i < 25; i++){
		for (int j = 0; j<80; j++){
			pantalla[i][j] = buffer_mapa[i][j];
		}
	}
}

void screen_imprimir_estado_inicial(){
	screen_elem agua;
	agua._char = '0';
	agua._mode = C_BG_CYAN | C_FG_CYAN;
	screen_elem elemWhite;
	elemWhite._char = '0';
	elemWhite._mode = C_BG_LIGHT_GREY | C_FG_LIGHT_GREY;
	screen_imprimir_grupo();
	for(int f = 1; f < 16; f++){
		for(int c = 0; c < VIDEO_COLS; c++){
			if ((c <= 49 || c >= 78) || f == 15){
				pantalla[f][c] = elemWhite;
			}	
		}
	}

	for(int f = 16; f < VIDEO_FILS-1; f++){
		for(int c = 2; c < VIDEO_COLS-1; c++)
			pantalla[f][c] = agua;
	}
	int j = 0;
	while(numeros[j] != 0){
		screen_elem nums;
		nums._char = numeros[j];
		nums._mode = C_BG_LIGHT_GREY | C_FG_BLACK;	
		pantalla[16+j][1] = nums;
		j++;
	}
	//imprime textos de navios
	imprimir_nombres();

	/*
	//ejemplo imprime una bandera
	bandera banderas[1];
	crear_banderas(banderas);
	int i = 0;
	while(i < 1){
		imprimir_bandera(banderas[i], 3 , 2);
	i++;
	}
	*/
	iniciar_banderas();

	//las tareas de la ultima linea
	screen_tareas_en_ejecucion_inicial();

	//estado inicial de tareas
	for (int i = 0; i<8; i++){
		screen_estado_tarea(i+1, (0x10000 + 0x2000 * i), (0x11000 + 0x2000 * i), 0);
	}

	//guardo estado inicial en buffer
	for (int i = 0; i < 25; i++){
		for (j = 0; j<80; j++){
			buffer_estado[i][j] = pantalla[i][j];
		}
	}

}

void screen_imprimir_estado(){
	//actualizo mapa con lo que hay en el buffer
	for (int i = 0; i < 25; i++){
		for (int j = 0; j<80; j++){
			pantalla[i][j] = buffer_estado[i][j];
		}
	}
}

void print_string(const char * text, unsigned int x, unsigned int y, unsigned short attr) {
    ca (*p)[VIDEO_COLS] = (ca (*)[VIDEO_COLS]) VIDEO_ADDR;
    int i;
    for (i = 0; text[i] != 0; i++) {
        p[y][x].c = (unsigned char) text[i];
        p[y][x].a = (unsigned char) attr;
        x++;
        if (x == VIDEO_COLS) {
            x = 0;
            y++;
        }
    }
}

void print_string_buffer(const char * text, unsigned int x, unsigned int y, unsigned short attr) {
    int i;
    for (i = 0; text[i] != 0; i++) {
        buffer_estado[y][x]._char = (unsigned char) text[i];
        buffer_estado[y][x]._mode = (unsigned char) attr;
        x++;
        if (x == VIDEO_COLS) {
            x = 0;
            y++;
        }
    }
}

void print_hex(unsigned int numero, int size, unsigned int x, unsigned int y, unsigned short attr) {
    ca (*p)[VIDEO_COLS] = (ca (*)[VIDEO_COLS]) VIDEO_ADDR;
    int i;
    char hexa[8];
    char letras[16] = "0123456789ABCDEF";
    hexa[0] = letras[ ( numero & 0x0000000F ) >> 0  ];
    hexa[1] = letras[ ( numero & 0x000000F0 ) >> 4  ];
    hexa[2] = letras[ ( numero & 0x00000F00 ) >> 8  ];
    hexa[3] = letras[ ( numero & 0x0000F000 ) >> 12 ];
    hexa[4] = letras[ ( numero & 0x000F0000 ) >> 16 ];
    hexa[5] = letras[ ( numero & 0x00F00000 ) >> 20 ];
    hexa[6] = letras[ ( numero & 0x0F000000 ) >> 24 ];
    hexa[7] = letras[ ( numero & 0xF0000000 ) >> 28 ];
    for(i = 0; i < size; i++) {
        p[y][x + size - i - 1].c = hexa[i];
        p[y][x + size - i - 1].a = attr;
    }
}

void print_hex_buffer(unsigned int numero, int size, unsigned int x, unsigned int y, unsigned short attr) {
    int i;
    char hexa[8];
    char letras[16] = "0123456789ABCDEF";
    hexa[0] = letras[ ( numero & 0x0000000F ) >> 0  ];
    hexa[1] = letras[ ( numero & 0x000000F0 ) >> 4  ];
    hexa[2] = letras[ ( numero & 0x00000F00 ) >> 8  ];
    hexa[3] = letras[ ( numero & 0x0000F000 ) >> 12 ];
    hexa[4] = letras[ ( numero & 0x000F0000 ) >> 16 ];
    hexa[5] = letras[ ( numero & 0x00F00000 ) >> 20 ];
    hexa[6] = letras[ ( numero & 0x0F000000 ) >> 24 ];
    hexa[7] = letras[ ( numero & 0xF0000000 ) >> 28 ];
    for(i = 0; i < size; i++) {
        buffer_estado[y][x + size - i - 1]._char = hexa[i];
        buffer_estado[y][x + size - i - 1]._mode = attr;
    }
}

void print_int(unsigned int n, unsigned int x, unsigned int y, unsigned short attr) {
    ca (*p)[VIDEO_COLS] = (ca (*)[VIDEO_COLS]) VIDEO_ADDR;
    if( n > 9 ) {
      int a = n / 10;
      n -= 10 * a;
      print_int(a,x-1,y,attr);
    }
    p[y][x].c = '0'+n;
    p[y][x].a = attr;
}

void print_int_buffer(unsigned int n, unsigned int x, unsigned int y, unsigned short attr) {
    if( n > 9 ) {
      int a = n / 10;
      n -= 10 * a;
      print_int(a,x-1,y,attr);
    }
    buffer_estado[y][x]._char = '0'+n;
    buffer_estado[y][x]._mode = attr;
}

void int_teclado(unsigned int letra){
	int recoLetra;
	if(letra <= 0x0A){ // letra e [1..9]
		recoLetra = letra - 1;
		numero_Color_Rnd(letra, recoLetra);
	}
	else if(letra == 0x0B){ // letra == 0 
		recoLetra = 0;
		numero_Color_Rnd(letra, recoLetra);
	}
	else if(letra == 0x12){ // letra == e
		modo_estado = 1;
		screen_imprimir_estado();
	}
	else if(letra == 0x32){ // letra == m
		modo_estado = 0;
		screen_imprimir_mapa();
	}	
}

void imprimir_registros(unsigned int *registros){
	int x = 51;
	int y = 2;
	//print_hex((unsigned int) *(registros+8), 8, x+4, y -1, (C_BG_BLACK | C_FG_WHITE));		
	for (int i = 0; i < 19; i++){
		if(i <= 12){
			print_string_buffer(nom_reg[19 - i], x, y + i, (C_BG_BLACK | C_FG_WHITE));
			print_hex_buffer((unsigned int) *(registros+19-i), 8, x+4, y +i, (C_BG_BLACK | C_FG_WHITE));

		}else{
			print_string_buffer(nom_reg[19 - i], x + 15, y + i - 13, (C_BG_BLACK | C_FG_WHITE));
			print_hex_buffer((unsigned int) *(registros+19-i), 8, x + 18, y+i-13, (C_BG_BLACK | C_FG_WHITE));
		}
	}
	print_string_buffer(nom_reg[0], x + 15, y + 7, (C_BG_BLACK | C_FG_WHITE));
	print_hex_buffer((unsigned int) *(registros), 8, x + 18, y+8, (C_BG_BLACK | C_FG_WHITE));

	if (modo_estado){
		screen_imprimir_estado();
	}
	
}

void screen_tareas_en_ejecucion_inicial(){
	screen_elem tarea;
	tarea._char = '0';
	tarea._mode = C_BG_LIGHT_GREY | C_FG_BLACK;
	screen_elem band;
	band._char = '0';
	band._mode = C_BG_BROWN  | C_FG_BLACK;
	for (int i = 1; i<=8; i++){
		//relojes de tareas
		tarea._char = '0' + (i);
		pantalla[24][1 + 3 * i] = tarea;
		tarea._char = '*';
		pantalla[24][2 + 3 * i] = tarea;
		//relojes de banderas
		band._char = '0' + (i);
		pantalla[24][29 + 3 * i] = band;
		band._char = '*';
		pantalla[24][30 + 3 * i] = band;
	} 
}

void screen_desalojartarea(unsigned int nro_tarea){
	buffer_estado[24][1 + 3 * nro_tarea]._mode = (C_BG_RED | C_FG_BLACK);
	buffer_estado[24][2 + 3 * nro_tarea]._mode = (C_BG_RED | C_FG_BLACK);
	buffer_estado[24][29 + 3 * nro_tarea]._mode = (C_BG_RED | C_FG_BLACK);
	buffer_estado[24][30 + 3 * nro_tarea]._mode = (C_BG_RED | C_FG_BLACK);
	buffer_mapa[24][1 + 3 * nro_tarea]._mode = (C_BG_RED | C_FG_BLACK);
	buffer_mapa[24][2 + 3 * nro_tarea]._mode = (C_BG_RED | C_FG_BLACK);
	buffer_mapa[24][29 + 3 * nro_tarea]._mode = (C_BG_RED | C_FG_BLACK);
	buffer_mapa[24][30 + 3 * nro_tarea]._mode = (C_BG_RED | C_FG_BLACK);

	//pinto la bandera para saber que la desaloje
	pintar_bandera(nro_tarea, (unsigned int)bandera_desalojada);

	

	if (modo_estado){
		screen_imprimir_estado();
	}else{
		screen_imprimir_mapa();
	}
}

void screen_estado_tarea(unsigned int nro_tarea, unsigned int p1, unsigned int p2, unsigned int p3){
	print_string("P1:0x", 3, (15 + nro_tarea), C_BG_CYAN | C_FG_BLACK);
	print_hex(p1, 8, 8, (15 + nro_tarea) , C_BG_CYAN | C_FG_BLACK);
	print_string("P2:0x", 17, (15 + nro_tarea), C_BG_CYAN | C_FG_BLACK);
	print_hex(p2, 8, 22, (15 + nro_tarea) , C_BG_CYAN | C_FG_BLACK);
	print_string("P3:0x", 31, (15 + nro_tarea), C_BG_CYAN | C_FG_BLACK);
	print_hex(p3, 8, 36, (15 + nro_tarea) , C_BG_CYAN | C_FG_BLACK);
}

void actualizar_estado_tarea(unsigned short nro_tarea, unsigned int nro_pag, unsigned int dir_pag){
	if(nro_pag == 1){
		print_string_buffer("P1:0x", 3, (15 + nro_tarea), C_BG_CYAN | C_FG_BLACK);
		print_hex_buffer(dir_pag, 8, 8, (15 + nro_tarea) , C_BG_CYAN | C_FG_BLACK);
	}else if (nro_pag == 2){
		print_string_buffer("P2:0x", 17, (15 + nro_tarea), C_BG_CYAN | C_FG_BLACK);
		print_hex_buffer(dir_pag, 8, 22, (15 + nro_tarea) , C_BG_CYAN | C_FG_BLACK);
	}else{
		print_string_buffer("P3:0x", 31, (15 + nro_tarea), C_BG_CYAN | C_FG_BLACK);
		print_hex_buffer(dir_pag, 8, 36, (15 + nro_tarea) , C_BG_CYAN | C_FG_BLACK);
	}
	if (modo_estado){
		screen_imprimir_estado();
	}
}

void pintar_bandera(unsigned short nrotarea, unsigned int dir_b){
	int x = 3;
	int y = 2;
	if(nrotarea <= 4){
		y = y + (12 * (nrotarea - 1));
	}else{
		x = 10;
		y = y + (12 * ((nrotarea - 1)%4));
	}


	screen_elem (*bandera_aux)[10]= (screen_elem (*)[10]) dir_b;

	int i, j;
	for (i = 0; i < 5; ++i) {
		for (j = 0; j < 10; ++j) {
			buffer_estado[i + x][j + y] = bandera_aux[i][j];
		}
	}
	if (modo_estado){
		screen_imprimir_estado();
	}
//static screen_elem (*pantalla)[VIDEO_COLS] = (screen_elem (*)[VIDEO_COLS]) VIDEO_ADDR;
	//breakpoint();
}

void screen_misil(unsigned int dir_misil){
	screen_elem agua;
	agua._char = '0';
	agua._mode = C_BG_CYAN | C_FG_CYAN;

	screen_elem misil;
	misil._char = '0';
	misil._mode = C_BG_RED | C_FG_RED;

	if (dir_ult_misil != 0){
		int nro_pagu = dir_ult_misil / TAMANO_PAGINA;
		int iu = nro_pagu / VIDEO_COLS; 
		int ju = nro_pagu % VIDEO_COLS;
		buffer_mapa[iu][ju]=agua;
	}

	dir_ult_misil = dir_misil;

	int nro_pag = dir_misil / TAMANO_PAGINA;
	int i = nro_pag / VIDEO_COLS; 
	int j = nro_pag % VIDEO_COLS;
	buffer_mapa[i][j] = misil;

	if (!modo_estado){
		screen_imprimir_mapa();
	}
}

void screen_navegar(unsigned int origen, unsigned int destino, unsigned int num_tarea){
	screen_elem agua;
	agua._char = '0';
	agua._mode = C_BG_CYAN | C_FG_CYAN;
	
	screen_elem barco;
	barco._char = '0' + (num_tarea);
	barco._mode = C_BG_BROWN | C_FG_WHITE;

	screen_elem choque;
	choque._char = 'X';
	choque._mode = C_BG_RED | C_FG_WHITE;

	int pos_origen = origen / TAMANO_PAGINA;
	int x_o = pos_origen / VIDEO_COLS; 
	int y_o = pos_origen % VIDEO_COLS;
	buffer_mapa[x_o][y_o] = agua;	
	
	int pos_destino = destino / TAMANO_PAGINA;
	int x_d = pos_destino / VIDEO_COLS; 
	int y_d = pos_destino % VIDEO_COLS;

	if (buffer_mapa[x_d][y_d]._mode == (C_BG_BROWN | C_FG_WHITE)){
		buffer_mapa[x_d][y_d] = choque;
	}else{
		buffer_mapa[x_d][y_d] = barco;
	}

	if (!modo_estado){
		screen_imprimir_mapa();
	}	

}

void screen_desembarcar(unsigned int destino, unsigned int num_tarea){
	screen_elem barco;
	barco._char = '0' + (num_tarea);
	barco._mode = C_BG_BROWN | C_FG_WHITE;

	int pos_destino = destino / TAMANO_PAGINA;
	int x_d = pos_destino / VIDEO_COLS; 
	int y_d = pos_destino % VIDEO_COLS;
	buffer_mapa[x_d][y_d] = barco;

	if (!modo_estado){
		screen_imprimir_mapa();
	}	

}

void screen_anclar(unsigned int origen, unsigned int destino, unsigned int num_tarea){
	screen_elem tierra;
	tierra._char = '0';
	tierra._mode = C_BG_GREEN | C_FG_GREEN;
	
	screen_elem ancla;
	ancla._char = '0' + (num_tarea);
	ancla._mode = C_BG_MAGENTA | C_FG_WHITE;

	screen_elem choque;
	choque._char = 'X';
	choque._mode = C_BG_RED | C_FG_WHITE;

	int pos_origen = origen / TAMANO_PAGINA;
	int x_o = pos_origen / VIDEO_COLS; 
	int y_o = pos_origen % VIDEO_COLS;
	buffer_mapa[x_o][y_o] = tierra;	
	
	int pos_destino = destino / TAMANO_PAGINA;
	int x_d = pos_destino / VIDEO_COLS; 
	int y_d = pos_destino % VIDEO_COLS;

	if(buffer_mapa[x_d][y_d]._mode == (C_BG_MAGENTA | C_FG_WHITE)){
		buffer_mapa[x_d][y_d] = choque;
	}else{
		buffer_mapa[x_d][y_d] = ancla;
	}

	if (!modo_estado){
		screen_imprimir_mapa();
	}	

}