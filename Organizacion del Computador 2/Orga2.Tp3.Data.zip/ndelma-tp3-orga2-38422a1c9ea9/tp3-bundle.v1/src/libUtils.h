/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones utiles
*/

#ifndef __LIBUTILS_H__
#define __LIBUTILS_H__

#define INIT_PRIME_A 102031
#define INIT_PRIME_C 199289
#define INIT_PRIME_X 223637
#define INIT_MOD_M 345643

unsigned int randPseudo(unsigned int value);

#endif  /* !__LIBUTILS_H__ */
