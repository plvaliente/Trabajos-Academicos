/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del scheduler
*/

#ifndef __SCHED_H__
#define __SCHED_H__

#include "tss.h"
#include "i386.h"
#include "screen.h"

void sched_inicializar();
unsigned short sched_proximo_indice();
unsigned short sched_proxima_bandera();
unsigned short sched_proxima_tarea();
void eliminar_tarea(unsigned short tarea);
unsigned short tareaactual();
unsigned short banderaactual();
unsigned short ejecucionactual();
unsigned short soybandera();
unsigned short dame_activas();


#endif	/* !__SCHED_H__ */
