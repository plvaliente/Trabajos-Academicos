/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de estructuras para administrar tareas
*/

#include "tss.h"
#include "i386.h"

  

static unsigned int EIP_banderas[8];
static unsigned int ESP0_banderas[8];


tss tarea_inicial;
tss tarea_idle;

static tss tss_navios[CANT_TAREAS];
static tss tss_banderas[CANT_TAREAS];

void restaurar_bandera(unsigned int i){
    //breakpoint();

    tss_banderas[i].eip = EIP_banderas[i];
    tss_banderas[i].esp = 0x40001FFC;
    tss_banderas[i].esp0 = ESP0_banderas[i];
    //breakpoint();
}

void tss_inicializar() {
	/***** TAREA INICIAL *****/

	tarea_inicial.eip = 0;
	tarea_inicial.esp = 0;
	tarea_inicial.ebp = 0;
	tarea_inicial.eflags = 0x02;
	tarea_inicial.cr3 = 0x0;
	tarea_inicial.gs = 0;
	tarea_inicial.ss = 0;
	tarea_inicial.fs = 0;
	tarea_inicial.ds = 0;
	tarea_inicial.cs = 0;
	tarea_inicial.es = 0;
	tarea_inicial.ss0 = 0;

	gdt[GDT_IDX_TAREA_INICIAL].base_0_15 = (unsigned short) BASE_0_15(&tarea_inicial);
	gdt[GDT_IDX_TAREA_INICIAL].base_23_16 = (unsigned char) BASE_23_16(&tarea_inicial);
	gdt[GDT_IDX_TAREA_INICIAL].base_31_24 = (unsigned char) BASE_31_24(&tarea_inicial);

	/***** TAREA IDLE *****/

	tarea_idle.eip = 0x40000000;
	tarea_idle.esp = 0x0002A000;
    tarea_idle.ebp = 0x0002A000;
    tarea_idle.esp0 = 0x0002A000;
    tarea_idle.ss0 = 0xA0;
	tarea_idle.eflags = 0x202;
	tarea_idle.cr3 = 0x27000;
    tarea_idle.dtrap = 0x0;
    tarea_idle.iomap = 0xFFFF;
    /*** SELECTORES***/
    //datos
	tarea_idle.gs = 0xA0;
	tarea_idle.ss = 0xA0;
	tarea_idle.ds = 0xA0;
	tarea_idle.es = 0xA0;
    tarea_idle.fs = 0xB0; //video
    tarea_idle.cs = 0x90; //codigo

	gdt[GDT_IDX_TAREA_IDLE].base_0_15 = (unsigned short) BASE_0_15(&tarea_idle);
	gdt[GDT_IDX_TAREA_IDLE].base_23_16 = (unsigned char) BASE_23_16(&tarea_idle);
	gdt[GDT_IDX_TAREA_IDLE].base_31_24 = (unsigned char) BASE_31_24(&tarea_idle);


    /***** TAREAS Y BANDERAS *****/
    int j = 0;
    /**Mapping T B 1**/
    unsigned int CR3_t1 = mmu_inicializar_dir_tarea(TASK_1_CODE_SRC_ADDR);

    /** MANDO A NAVEGAR TAREAS Y ACTUALIZO SU MAPA **/
    screen_desembarcar(TAREA_1_MAR_P1, 1);
    screen_desembarcar(TAREA_1_MAR_P2, 1);
    mmu_copiar_y_mapear(0x40000000,CR3_t1,TAREA_1_MAR_P1,PRESENT_RW_USER);
    mmu_copiar_y_mapear(0x40001000,CR3_t1,TAREA_1_MAR_P2,PRESENT_RW_USER);
    actualizar_estado_tarea(1,1, TAREA_1_MAR_P1);
    actualizar_estado_tarea(1,2, TAREA_1_MAR_P2);


    /** Mapping Cont **/
    unsigned int pilaT1 = prox_pag_libre();
    EIP_banderas[j] = TASK_1_CODE_SRC_ADDR + *((unsigned int*)(TASK_1_CODE_SRC_ADDR + TASK_SIZE - 4));
    ESP0_banderas[j] = pilaT1 + 0x1000;
    
    /**T 1**/
    tss_navios[j].esp0 = (pilaT1 + 0x1000);
    tss_navios[j].cr3 = CR3_t1;
    gdt[GDT_IDX_TAREA_1].base_0_15 = (unsigned short) BASE_0_15(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_1].base_23_16 = (unsigned char) BASE_23_16(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_1].base_31_24 = (unsigned char) BASE_31_24(&tss_navios[j]);
    /**B 1**/
    tss_banderas[j].esp0 = (pilaT1 + 0x800);
    tss_banderas[j].cr3 = CR3_t1;
    gdt[GDT_IDX_BANDERA_1].base_0_15 = (unsigned short) BASE_0_15(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_1].base_23_16 = (unsigned char) BASE_23_16(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_1].base_31_24 = (unsigned char) BASE_31_24(&tss_banderas[j]);
    j++;

    /**Mapping T B 2**/
    unsigned int CR3_t2 = mmu_inicializar_dir_tarea(TASK_2_CODE_SRC_ADDR);

    /** MANDO A NAVEGAR TAREAS Y ACTUALIZO SU MAPA **/
    screen_desembarcar(TAREA_2_MAR_P1, 2);
    screen_desembarcar(TAREA_2_MAR_P2, 2);
    mmu_copiar_y_mapear(0x40000000,CR3_t2,TAREA_2_MAR_P1,PRESENT_RW_USER);
    mmu_copiar_y_mapear(0x40001000,CR3_t2,TAREA_2_MAR_P2,PRESENT_RW_USER);
    actualizar_estado_tarea(2,1, TAREA_2_MAR_P1);
    actualizar_estado_tarea(2,2, TAREA_2_MAR_P2);


    /** Mapping Cont **/     
    unsigned int pilaT2 = prox_pag_libre();
    EIP_banderas[j] = TASK_2_CODE_SRC_ADDR + *((unsigned int*)(TASK_2_CODE_SRC_ADDR + TASK_SIZE - 4));
    ESP0_banderas[j] = pilaT2 + 0x1000;
    /**T 2**/
    tss_navios[j].esp0 = (pilaT2 + 0x1000);
    tss_navios[j].cr3 = CR3_t2;
    gdt[GDT_IDX_TAREA_2].base_0_15 = (unsigned short) BASE_0_15(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_2].base_23_16 = (unsigned char) BASE_23_16(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_2].base_31_24 = (unsigned char) BASE_31_24(&tss_navios[j]);
    /**B 2**/
    tss_banderas[j].esp0 = (pilaT2 + 0x800);
    tss_banderas[j].cr3 = CR3_t2;
    gdt[GDT_IDX_BANDERA_2].base_0_15 = (unsigned short) BASE_0_15(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_2].base_23_16 = (unsigned char) BASE_23_16(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_2].base_31_24 = (unsigned char) BASE_31_24(&tss_banderas[j]);
    j++;

    /**Mapping T B 3**/
    unsigned int CR3_t3 = mmu_inicializar_dir_tarea(TASK_3_CODE_SRC_ADDR);

    /** MANDO A NAVEGAR TAREAS Y ACTUALIZO SU MAPA **/
    screen_desembarcar(TAREA_3_MAR_P1, 3);
    screen_desembarcar(TAREA_3_MAR_P2, 3);
    mmu_copiar_y_mapear(0x40000000,CR3_t3,TAREA_3_MAR_P1,PRESENT_RW_USER);
    mmu_copiar_y_mapear(0x40001000,CR3_t3,TAREA_3_MAR_P2,PRESENT_RW_USER);
    actualizar_estado_tarea(3,1, TAREA_3_MAR_P1);
    actualizar_estado_tarea(3,2, TAREA_3_MAR_P2);


    /** Mapping Cont **/      
    unsigned int pilaT3 = prox_pag_libre();
    EIP_banderas[j] = TASK_3_CODE_SRC_ADDR + *((unsigned int*)(TASK_3_CODE_SRC_ADDR + TASK_SIZE - 4));
    ESP0_banderas[j] = pilaT3 + 0x1000;
    /**T 3**/
    tss_navios[j].esp0 = (pilaT3 + 0x1000);
    tss_navios[j].cr3 = CR3_t3;
    gdt[GDT_IDX_TAREA_3].base_0_15 = (unsigned short) BASE_0_15(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_3].base_23_16 = (unsigned char) BASE_23_16(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_3].base_31_24 = (unsigned char) BASE_31_24(&tss_navios[j]);
    /**B 3**/
    tss_banderas[j].esp0 = (pilaT3 + 0x800);
    tss_banderas[j].cr3 = CR3_t3;
    gdt[GDT_IDX_BANDERA_3].base_0_15 = (unsigned short) BASE_0_15(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_3].base_23_16 = (unsigned char) BASE_23_16(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_3].base_31_24 = (unsigned char) BASE_31_24(&tss_banderas[j]);
    j++;

    /**Mapping T B 4**/
    unsigned int CR3_t4 = mmu_inicializar_dir_tarea(TASK_4_CODE_SRC_ADDR);

    /** MANDO A NAVEGAR TAREAS Y ACTUALIZO SU MAPA **/
    screen_desembarcar(TAREA_4_MAR_P1, 4);
    screen_desembarcar(TAREA_4_MAR_P2, 4);
    mmu_copiar_y_mapear(0x40000000,CR3_t4,TAREA_4_MAR_P1,PRESENT_RW_USER);
    mmu_copiar_y_mapear(0x40001000,CR3_t4,TAREA_4_MAR_P2,PRESENT_RW_USER);
    actualizar_estado_tarea(4,1, TAREA_4_MAR_P1);
    actualizar_estado_tarea(4,2, TAREA_4_MAR_P2);


    /** Mapping Cont **/     
    unsigned int pilaT4 = prox_pag_libre();
    EIP_banderas[j] = TASK_4_CODE_SRC_ADDR + *((unsigned int*)(TASK_4_CODE_SRC_ADDR + TASK_SIZE - 4));
    ESP0_banderas[j] = pilaT4 + 0x1000;
    /**T 4**/
    tss_navios[j].esp0 = (pilaT4 + 0x1000);
    tss_navios[j].cr3 = CR3_t4;
    gdt[GDT_IDX_TAREA_4].base_0_15 = (unsigned short) BASE_0_15(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_4].base_23_16 = (unsigned char) BASE_23_16(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_4].base_31_24 = (unsigned char) BASE_31_24(&tss_navios[j]);
    /**B 4**/
    tss_banderas[j].esp0 = (pilaT4 + 0x800);
    tss_banderas[j].cr3 = CR3_t4;
    gdt[GDT_IDX_BANDERA_4].base_0_15 = (unsigned short) BASE_0_15(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_4].base_23_16 = (unsigned char) BASE_23_16(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_4].base_31_24 = (unsigned char) BASE_31_24(&tss_banderas[j]);
    j++;

    /**Mapping T B 5**/
    unsigned int CR3_t5 = mmu_inicializar_dir_tarea(TASK_5_CODE_SRC_ADDR);

    /** MANDO A NAVEGAR TAREAS Y ACTUALIZO SU MAPA **/
    screen_desembarcar(TAREA_5_MAR_P1, 5);
    screen_desembarcar(TAREA_5_MAR_P2, 5);
    mmu_copiar_y_mapear(0x40000000,CR3_t5,TAREA_5_MAR_P1,PRESENT_RW_USER);
    mmu_copiar_y_mapear(0x40001000,CR3_t5,TAREA_5_MAR_P2,PRESENT_RW_USER);
    actualizar_estado_tarea(5,1, TAREA_5_MAR_P1);
    actualizar_estado_tarea(5,2, TAREA_5_MAR_P2);


    /** Mapping Cont **/      
    unsigned int pilaT5 = prox_pag_libre();
    EIP_banderas[j] = TASK_5_CODE_SRC_ADDR + *((unsigned int*)(TASK_5_CODE_SRC_ADDR + TASK_SIZE - 4));
    ESP0_banderas[j] = pilaT5 + 0x1000;
    /**T 5**/
    tss_navios[j].esp0 = (pilaT5 + 0x1000);
    tss_navios[j].cr3 = CR3_t5;
    gdt[GDT_IDX_TAREA_5].base_0_15 = (unsigned short) BASE_0_15(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_5].base_23_16 = (unsigned char) BASE_23_16(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_5].base_31_24 = (unsigned char) BASE_31_24(&tss_navios[j]);
    /**B 5**/
    tss_banderas[j].esp0 = (pilaT5 + 0x800);
    tss_banderas[j].cr3 = CR3_t5;
    gdt[GDT_IDX_BANDERA_5].base_0_15 = (unsigned short) BASE_0_15(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_5].base_23_16 = (unsigned char) BASE_23_16(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_5].base_31_24 = (unsigned char) BASE_31_24(&tss_banderas[j]);
    j++;

    /**Mapping T B 6**/
    unsigned int CR3_t6 = mmu_inicializar_dir_tarea(TASK_6_CODE_SRC_ADDR);

    /** MANDO A NAVEGAR TAREAS Y ACTUALIZO SU MAPA **/
    screen_desembarcar(TAREA_6_MAR_P1, 6);
    screen_desembarcar(TAREA_6_MAR_P2, 6);
    mmu_copiar_y_mapear(0x40000000,CR3_t6,TAREA_6_MAR_P1,PRESENT_RW_USER);
    mmu_copiar_y_mapear(0x40001000,CR3_t6,TAREA_6_MAR_P2,PRESENT_RW_USER);
    actualizar_estado_tarea(6,1, TAREA_6_MAR_P1);
    actualizar_estado_tarea(6,2, TAREA_6_MAR_P2);


    /** Mapping Cont **/      
    unsigned int pilaT6 = prox_pag_libre();
    EIP_banderas[j] = TASK_6_CODE_SRC_ADDR + *((unsigned int*)(TASK_6_CODE_SRC_ADDR + TASK_SIZE - 4));
    ESP0_banderas[j] = pilaT6 + 0x1000;
    /**T 6**/
    tss_navios[j].esp0 = (pilaT6 + 0x1000);
    tss_navios[j].cr3 = CR3_t6;
    gdt[GDT_IDX_TAREA_6].base_0_15 = (unsigned short) BASE_0_15(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_6].base_23_16 = (unsigned char) BASE_23_16(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_6].base_31_24 = (unsigned char) BASE_31_24(&tss_navios[j]);
    /**B 6**/
    tss_banderas[j].esp0 = (pilaT6 + 0x800);
    tss_banderas[j].cr3 = CR3_t6;
    gdt[GDT_IDX_BANDERA_6].base_0_15 = (unsigned short) BASE_0_15(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_6].base_23_16 = (unsigned char) BASE_23_16(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_6].base_31_24 = (unsigned char) BASE_31_24(&tss_banderas[j]);
    j++;

    /**Mapping T B 7**/
    unsigned int CR3_t7 = mmu_inicializar_dir_tarea(TASK_7_CODE_SRC_ADDR);

    /** MANDO A NAVEGAR TAREAS Y ACTUALIZO SU MAPA **/
    screen_desembarcar(TAREA_7_MAR_P1, 7);
    screen_desembarcar(TAREA_7_MAR_P2, 7);
    mmu_copiar_y_mapear(0x40000000,CR3_t7,TAREA_7_MAR_P1,PRESENT_RW_USER);
    mmu_copiar_y_mapear(0x40001000,CR3_t7,TAREA_7_MAR_P2,PRESENT_RW_USER);
    actualizar_estado_tarea(7,1, TAREA_7_MAR_P1);
    actualizar_estado_tarea(7,2, TAREA_7_MAR_P2);

    /** Mapping Cont **/      
    unsigned int pilaT7 = prox_pag_libre();
    EIP_banderas[j] = TASK_7_CODE_SRC_ADDR + *((unsigned int*)(TASK_7_CODE_SRC_ADDR + TASK_SIZE - 4));
    ESP0_banderas[j] = pilaT7 + 0x1000;
    /**T 7**/
    tss_navios[j].esp0 = (pilaT7 + 0x1000);
    tss_navios[j].cr3 = CR3_t7;
    gdt[GDT_IDX_TAREA_7].base_0_15 = (unsigned short) BASE_0_15(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_7].base_23_16 = (unsigned char) BASE_23_16(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_7].base_31_24 = (unsigned char) BASE_31_24(&tss_navios[j]);
    /**B 7**/
    tss_banderas[j].esp0 = (pilaT7 + 0x800);
    tss_banderas[j].cr3 = CR3_t7;
    gdt[GDT_IDX_BANDERA_7].base_0_15 = (unsigned short) BASE_0_15(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_7].base_23_16 = (unsigned char) BASE_23_16(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_7].base_31_24 = (unsigned char) BASE_31_24(&tss_banderas[j]);
    j++;

    /**Mapping T B 8**/
    unsigned int CR3_t8 = mmu_inicializar_dir_tarea(TASK_8_CODE_SRC_ADDR);


    /** MANDO A NAVEGAR TAREAS Y ACTUALIZO SU MAPA **/
    screen_desembarcar(TAREA_8_MAR_P1, 8);
    screen_desembarcar(TAREA_8_MAR_P2, 8);
    mmu_copiar_y_mapear(0x40000000,CR3_t8,TAREA_8_MAR_P1,PRESENT_RW_USER);
    mmu_copiar_y_mapear(0x40001000,CR3_t8,TAREA_8_MAR_P2,PRESENT_RW_USER);
    actualizar_estado_tarea(8,1, TAREA_8_MAR_P1);
    actualizar_estado_tarea(8,2, TAREA_8_MAR_P2);

    //ancla
    screen_anclar(0x0, 0x0, 8);

    /** Mapping Cont **/      
    unsigned int pilaT8 = prox_pag_libre();
    EIP_banderas[j] = TASK_8_CODE_SRC_ADDR + *((unsigned int*)(TASK_8_CODE_SRC_ADDR + TASK_SIZE - 4));
    ESP0_banderas[j] = pilaT8 + 0x1000;
    /**T 8**/
    tss_navios[j].esp0 = (pilaT8 + 0x1000);
    tss_navios[j].cr3 = CR3_t8;
    gdt[GDT_IDX_TAREA_8].base_0_15 = (unsigned short) BASE_0_15(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_8].base_23_16 = (unsigned char) BASE_23_16(&tss_navios[j]);
    gdt[GDT_IDX_TAREA_8].base_31_24 = (unsigned char) BASE_31_24(&tss_navios[j]);
    /**B 8**/
    tss_banderas[j].esp0 = (pilaT8 + 0x800);
    tss_banderas[j].cr3 = CR3_t8;
    gdt[GDT_IDX_BANDERA_8].base_0_15 = (unsigned short) BASE_0_15(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_8].base_23_16 = (unsigned char) BASE_23_16(&tss_banderas[j]);
    gdt[GDT_IDX_BANDERA_8].base_31_24 = (unsigned char) BASE_31_24(&tss_banderas[j]);
    j++;
    
    /** Termino de inicializas las tareas en la TSS **/
    for(int i = 0 ; i < 8 ; ++i){
        /* TAREAS */
        tss_navios[i].eip = 0x40000000;
        tss_navios[i].esp = 0x40001C00;
        tss_navios[i].ebp = 0x40001C00;
        //la pag libre + 4k-1(ultima posicion)

        tss_navios[i].ss0 = 0xA0; //datos priv 0
        tss_navios[i].eflags = 0x202;

        tss_navios[i].dtrap = 0x0;
        tss_navios[i].iomap = 0xFFFF;
        /*** SELECTORES***/
        //datos
        tss_navios[i].gs = 0xAB; 
        tss_navios[i].ss = 0xAB;
        tss_navios[i].ds = 0xAB; 
        tss_navios[i].es = 0xAB;
        tss_navios[i].fs = 0xAB; //video es lvl 0, no puedo ponerlo, lo necesito?
        tss_navios[i].cs = 0x9B; //codigo 

        /* BANDERAS */

        tss_banderas[i].eip = EIP_banderas[i];        
        tss_banderas[i].esp = 0x40001FFC; // o B
        tss_banderas[i].ebp = 0x40001FFC; // o B
        //la pag libre + 2k-1(mitad de pag)

        tss_banderas[i].ss0 = 0xA0; //datos priv 0?
        tss_banderas[i].eflags = 0x202;

        tss_banderas[i].dtrap = 0x0;
        tss_banderas[i].iomap = 0xFFFF;
        /*** SELECTORES***/
        //datos
        tss_banderas[i].gs = 0xA0;
        tss_banderas[i].ss = 0xA0;
        tss_banderas[i].ds = 0xA0;
        tss_banderas[i].es = 0xA0;
        tss_banderas[i].fs = 0xA0; //video es lvl 0, no puedo ponerlo, lo necesito?
        tss_banderas[i].cs = 0x90; //codigo
    }
	
}




