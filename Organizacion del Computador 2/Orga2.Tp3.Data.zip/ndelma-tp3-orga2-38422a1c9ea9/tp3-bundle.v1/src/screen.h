/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del scheduler
*/

#ifndef __SCREEN_H__
#define __SCREEN_H__


/* Definicion de la pantalla */
#define VIDEO_FILS 25
#define VIDEO_COLS 80
#define VIDEO_ADDR 0xB8000

#include "i386.h"
#include "defines.h"

typedef struct screen_elem {
   unsigned char _char;
   unsigned char _mode;
} __attribute__((__packed__)) screen_elem;

/* Estructura de para acceder a memoria de video */
typedef struct ca_s {
    unsigned char c;
    unsigned char a;
} ca;

typedef struct bandera{
	screen_elem band_chars[5][10];
}__attribute__((__packed__)) bandera;

typedef struct registros{
	unsigned int reg[20];
}__attribute__((__packed__)) registros;

void screen_pintar_pantalla();

void screen_imprimir_grupo();

void print_Excepciones(unsigned int error, unsigned int num_tarea);

void screen_imprimir_mapa_inicial();

void screen_imprimir_mapa();

void screen_imprimir_estado_inicial();

void screen_imprimir_estado();

void screen_tareas_en_ejecucion_inicial();

void screen_desalojartarea(unsigned int nro_tarea);

void screen_misil(unsigned int dir_misil);

void screen_navegar(unsigned int origen, unsigned int destino, unsigned int num_tarea);

void screen_desembarcar(unsigned int destino, unsigned int num_tarea);

void screen_anclar(unsigned int origen, unsigned int destino, unsigned int num_tarea);

void actualizar_estado_tarea(unsigned short nro_tarea, unsigned int nro_pag, unsigned int dir_pag);

void screen_estado_tarea(unsigned int nro_tarea, unsigned int p1, unsigned int p2, unsigned int p3);

void print_string(const char * text, unsigned int x, unsigned int y, unsigned short attr);

void print_string_buffer(const char * text, unsigned int x, unsigned int y, unsigned short attr);

void print_hex(unsigned int numero, int size, unsigned int x, unsigned int y, unsigned short attr);

void print_hex_buffer(unsigned int numero, int size, unsigned int x, unsigned int y, unsigned short attr);

void print_int(unsigned int n, unsigned int x, unsigned int y, unsigned short attr);

void print_int_buffer(unsigned int n, unsigned int x, unsigned int y, unsigned short attr);

void pintar_bandera(unsigned short nrotarea, unsigned int dir_bandera_buffer);

#endif  /* !__SCREEN_H__ */
