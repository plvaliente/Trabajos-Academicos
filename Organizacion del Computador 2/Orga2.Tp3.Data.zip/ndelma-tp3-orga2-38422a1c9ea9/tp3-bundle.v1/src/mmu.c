/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del manejador de memoria
*/

#include "mmu.h"


static unsigned int prox_libre = 0x31000;

unsigned int prox_pag_libre(){
	unsigned int aux = prox_libre;
	prox_libre += 0x1000;
	return aux;
} 

void mmu_mapear_pagina(unsigned int virtual, unsigned int cr3, unsigned int fisica, unsigned int attr){
	directorio (* _dir) = (directorio (*)) (cr3 & 0xFFFFF000);
	unsigned int idxDir = PDE_INDEX(virtual);
	unsigned int idxTbl = PTE_INDEX(virtual);
	if( (_dir->tablas_b_0_31[idxDir] & 1) == 0){
		unsigned int tbl_ADDR = prox_pag_libre();
		_dir->tablas_b_0_31[idxDir] = (tbl_ADDR | attr);
	}
	tabla (* _tbl) = (tabla (*)) ((_dir->tablas_b_0_31[idxDir]) & 0xFFFFF000) ;
	_tbl->paginas_b_0_31[idxTbl] = ((fisica & 0xFFFFF000) | attr);
	tlbflush();
}
void mmu_unmapear_pagina(unsigned int virtual, unsigned int cr3){
	directorio (* _dir) = (directorio (*)) (cr3 & 0xFFFFF000);
	unsigned int idxDir = PDE_INDEX(virtual);
	unsigned int idxTbl = PTE_INDEX(virtual);
	tabla (* _tbl) = (tabla (*)) _dir->tablas_b_0_31[idxDir];
	_tbl->paginas_b_0_31[idxTbl] = PG_READ_WRITE;
	tlbflush();
}

void mmu_inicializar() {	
	/****** ARMO DIRECTORIO ******/
	directorio (* _dir) = (directorio (*)) DIR_PAG_ADDR;
	_dir->tablas_b_0_31[0] =  ( DIR_TBL1_ADDR | PRESENT_RW ); //PRESENT Y RW
	_dir->tablas_b_0_31[1] =  ( DIR_TBL2_ADDR | PRESENT_RW ); //PRESENT Y RW
	for(int i = 2 ; i < 1024 ; i++){
		_dir->tablas_b_0_31[i] = PG_READ_WRITE; //RW
	}

	/****** ARMO TABLA 1 ******/
	tabla (* _tbl1) = (tabla (*)) DIR_TBL1_ADDR;
	for(int i = 0 ; i < 1024 ; i++){
		_tbl1->paginas_b_0_31[i] = ( (i << 12) | PRESENT_RW ); //PRESENT Y RW
	}
	
	/****** ARMO TABLA 2 ******/
	
	tabla (* _tbl2) = (tabla (*)) DIR_TBL2_ADDR;
	for(int i = 0 ; i < 896 ; i++){
	//	_tbl2->paginas_b_0_31[i] = ( prox_pag_libre() | PRESENT_RW );
		_tbl2->paginas_b_0_31[i] = ( (i<<12) | PRESENT_RW ) + 0x400000; //PRESENT Y RW
	}
	for(int i = 896 ; i < 1024 ; i++){
		_tbl2->paginas_b_0_31[i] = PG_READ_WRITE; //RW
	}

	//Definicion para idle
	unsigned int dir_Tbl3_Tar = prox_pag_libre();
	_dir->tablas_b_0_31[PDE_INDEX(0x40000000)] =  ( dir_Tbl3_Tar | PRESENT_RW ); //PRESENT Y RW
	tabla (* _tbl3) = (tabla (*)) dir_Tbl3_Tar;
	for(int i = 0 ; i < 1024 ; i++){
		_tbl3->paginas_b_0_31[i] = ( (i << 12) | PG_READ_WRITE ); //RW
	}

	mmu_mapear_pagina(0x40000000, DIR_PAG_ADDR, TASK_IDLE_CODE_SRC_ADDR, PRESENT_RW); //TAREA IDLE
	mmu_mapear_pagina(0x40001000, DIR_PAG_ADDR, TASK_IDLE_CODE_SRC_ADDR + TAMANO_PAGINA, PRESENT_RW); //TAREA IDLE 	
		
}

unsigned int mmu_inicializar_dir_tarea(unsigned int dirTarea) {	
	/****** ARMO DIRECTORIO ******/
	unsigned int dir_Pag_Tar = (prox_pag_libre() & 0xFFFFF000);
	//unsigned int dir_Pag_Tar = (cr3 & 0xFFFFF000);
	directorio (* _dir) = (directorio (*)) dir_Pag_Tar ;
	unsigned int dir_Tbl1_Tar = prox_pag_libre();
	unsigned int dir_Tbl2_Tar = prox_pag_libre();
	_dir->tablas_b_0_31[0] =  ( dir_Tbl1_Tar | PRESENT_RW ); //PRESENT Y RW
	_dir->tablas_b_0_31[1] =  ( dir_Tbl2_Tar | PRESENT_RW ); //PRESENT Y RW
	for(int i = 2 ; i < 1024 ; i++){
		_dir->tablas_b_0_31[i] = PG_READ_WRITE; //RW
	}

	/********** SETEO IDE MAP ***********/
	/****** ARMO TABLA 1 ******/
	tabla (* _tbl1) = (tabla (*)) dir_Tbl1_Tar;
	for(int i = 0 ; i < 1024 ; i++){
		_tbl1->paginas_b_0_31[i] = ( (i << 12) | PRESENT_RW ); //PRESENT Y RW
	}
	
	/****** ARMO TABLA 2 ******/
	
	tabla (* _tbl2) = (tabla (*)) dir_Tbl2_Tar;
	for(int i = 0 ; i < 896 ; i++){
		_tbl2->paginas_b_0_31[i] = ( (i<<12) | PRESENT_RW ) + 0x400000; //PRESENT Y RW
	}
	for(int i = 896 ; i < 1024 ; i++){
		_tbl2->paginas_b_0_31[i] = PG_READ_WRITE; //RW
	}

	/********** SETEO LA OTRA PAG ***********/
	
	unsigned int dir_Tbl3_Tar = prox_pag_libre();
	_dir->tablas_b_0_31[PDE_INDEX(0x40000000)] =  ( dir_Tbl3_Tar | PRESENT_RW_USER ); //PRESENT Y RW
	tabla (* _tbl3) = (tabla (*)) dir_Tbl3_Tar;
	for(int i = 0 ; i < 1024 ; i++){
		_tbl3->paginas_b_0_31[i] = ( (i << 12) | PG_READ_WRITE ); //RW
	}

	mmu_mapear_pagina(0x40000000, dir_Pag_Tar, dirTarea, PRESENT_RW_USER); //TAREA PAG 1
	mmu_mapear_pagina(0x40001000, dir_Pag_Tar, (dirTarea + 0x1000), PRESENT_RW_USER); //TAREA PAG 2 
	mmu_mapear_pagina(0x40002000, dir_Pag_Tar, 0, (PGUSER | PG_PRESENT)); //ANCLA 

	return dir_Pag_Tar;
}

void mmu_copiar_y_mapear(unsigned int virtual, unsigned int cr3, unsigned int fisicaNueva, unsigned int attr){
	char* fisicaActual = (char*)obtener_fisica(cr3,virtual);

	//char* fisicaActual = (char*)TASK_1_CODE_SRC_ADDR;
	char* fisicaNuev = (char*) fisicaNueva;
	for (unsigned int i = 0; i < TAMANO_PAGINA; i++){
		fisicaNuev[i] = fisicaActual[i];
	}

	//mmu_unmapear_pagina(virtual,cr3);
	
	mmu_mapear_pagina(virtual,cr3,fisicaNueva,attr);

	
	tlbflush();	
}


unsigned int obtener_fisica(unsigned int cr3, unsigned int logica){
	directorio (* _dir) = (directorio (*)) (cr3 & 0xFFFFF000);
	unsigned int idxDir = PDE_INDEX(logica);
	unsigned int idxTbl = PTE_INDEX(logica);
	tabla (* _tbl) = (tabla (*)) ((_dir->tablas_b_0_31[idxDir]) & 0xFFFFF000) ;
	unsigned int fisica = ((_tbl->paginas_b_0_31[idxTbl]) & 0xFFFFF000) ;
	fisica += OFFSET(logica);
	return fisica;
}



