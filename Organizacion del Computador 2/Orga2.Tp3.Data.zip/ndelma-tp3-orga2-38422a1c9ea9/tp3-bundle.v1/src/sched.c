/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del scheduler
*/

#include "sched.h"

unsigned short IDX_GDT_TAREAS[8];
unsigned short IDX_GDT_BANDERAS[8];
unsigned short tarea_actual;
unsigned short bandera_actual;
unsigned short tareas_activas;
//cuenta de a 3 tareas para hacer el cambia a modo bandera
unsigned short count_ciclo_tareas;
//cuento las banderas a ejecutar para volver a las tareas cuando ejecute todas
unsigned short count_ciclo_banderas;

//modo = 0 es tarea, 1 es bandera
unsigned short modo_bandera;

void sched_inicializar() {
	
    IDX_GDT_TAREAS[0] = (GDT_IDX_TAREA_1 << 3);
    IDX_GDT_TAREAS[1] = (GDT_IDX_TAREA_2 << 3);
    IDX_GDT_TAREAS[2] = (GDT_IDX_TAREA_3 << 3);
    IDX_GDT_TAREAS[3] = (GDT_IDX_TAREA_4 << 3);
    IDX_GDT_TAREAS[4] = (GDT_IDX_TAREA_5 << 3);
    IDX_GDT_TAREAS[5] = (GDT_IDX_TAREA_6 << 3);
    IDX_GDT_TAREAS[6] = (GDT_IDX_TAREA_7 << 3);
    IDX_GDT_TAREAS[7] = (GDT_IDX_TAREA_8 << 3);

    IDX_GDT_BANDERAS[0] = (GDT_IDX_BANDERA_1 << 3);
    IDX_GDT_BANDERAS[1] = (GDT_IDX_BANDERA_2 << 3);
    IDX_GDT_BANDERAS[2] = (GDT_IDX_BANDERA_3 << 3);
    IDX_GDT_BANDERAS[3] = (GDT_IDX_BANDERA_4 << 3);
    IDX_GDT_BANDERAS[4] = (GDT_IDX_BANDERA_5 << 3);
    IDX_GDT_BANDERAS[5] = (GDT_IDX_BANDERA_6 << 3);
    IDX_GDT_BANDERAS[6] = (GDT_IDX_BANDERA_7 << 3);
    IDX_GDT_BANDERAS[7] = (GDT_IDX_BANDERA_8 << 3);

    tarea_actual = -1;
	bandera_actual = -1;
	tareas_activas = 8;
    count_ciclo_tareas = 3;
    count_ciclo_banderas = 8;
	modo_bandera = 0;

}

unsigned short sched_proximo_indice(){
    unsigned short index = 0;
    if(tareas_activas > 0){
        if(!modo_bandera){
        /*** MODO TAREA ***/
            //si ejecute menos de 3 tareas seguidas sigo en modo tarea
            if(count_ciclo_tareas > 0){
                index = sched_proxima_tarea();
                count_ciclo_tareas--;

            }else{
            //sino paso a modo bandera
                modo_bandera = 1;
                count_ciclo_banderas = tareas_activas;
                index = sched_proximo_indice();
            }

         }else{
         /*** MODO BANDERA ***/
             //si no ejecute todas las banderas sigo en  modo bandera
             if(count_ciclo_banderas > 0){
                 index = sched_proxima_bandera();
                 count_ciclo_banderas--;
             }else{
             //sino cambio a modo tarea

                 modo_bandera = 0;
                 count_ciclo_tareas = 3;
                 index = sched_proximo_indice();
             }
         }

    }

    return index;
}


unsigned short sched_proxima_tarea() {
    //mod 8 se usa para recorrer las tareas circularmente
    int i = tarea_actual;
    unsigned short prox_tar = IDX_GDT_TAREAS[(i + 1)%8];
    while(prox_tar == 0){
    	i++;
    	prox_tar = IDX_GDT_TAREAS[(i + 1)%8];
    }
    tarea_actual = (i+1)%8;
    return prox_tar;
}

unsigned short sched_proxima_bandera() {
    //mod 8 se usa para recorrer las banderas circularmente
    int i = bandera_actual;
    //if (i == 5){
      //  breakpoint();
    //}
    unsigned short prox_ban = IDX_GDT_BANDERAS[(i + 1)%8];
    //if (prox_ban == 0){
        //breakpoint();
    //}
    while(prox_ban == 0){
    	i++;
    	prox_ban = IDX_GDT_BANDERAS[(i + 1)%8];
    }
    bandera_actual = ((i+1) % 8);
    restaurar_bandera(bandera_actual);
    return prox_ban;
}

void eliminar_tarea(unsigned short tarea){
    screen_desalojartarea(ejecucionactual());
    IDX_GDT_TAREAS[tarea - 1] = 0;
    IDX_GDT_BANDERAS[tarea - 1] = 0;
    tareas_activas--;

}

unsigned short tareaactual(){
    return (tarea_actual + 1);
}

unsigned short banderaactual(){
    return (bandera_actual + 1);
}

unsigned short ejecucionactual(){
    if(!modo_bandera){
        return tareaactual();
    }else{
        return banderaactual();
    }
}

unsigned short soybandera(){
    return modo_bandera;
}

unsigned short dame_activas(){
    return tareas_activas;
}